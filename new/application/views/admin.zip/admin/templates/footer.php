</div>

</div>
<script src="<?= base_url() ?>assets/main.js"></script>
<script src="<?= base_url() ?>assets/trix.js"></script>
</body>

</html>
