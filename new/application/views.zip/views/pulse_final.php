<div class="ayu">
          <img class="klo" src="<?= base_url() ?>assets/1.png">
     </div>