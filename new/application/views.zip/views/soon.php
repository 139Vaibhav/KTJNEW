
        <main class="main">
                <div class="container">
                        <div class="middle">
                                
                                <p class="soon">Coming Soon !!</p>
                        </div>
                        <div style="clear:both" style="color: white;"></div>
                        <div class="bottom">
                                <a href="https://www.facebook.com/ktj.iitkgp/"><img src="<?= base_url() ?>assets/impimages/facebook.png"
                                                alt="Snow" class="botlink1"></img></a>
                                <a href="https://www.instagram.com/ktj.iitkgp/"><img src="<?= base_url() ?>assets/impimages/instagram.png"
                                                alt="Snow" class="botlink2"></img></a>
                                <a href="https://www.youtube.com/channel/UCJBD3V9lQm8d5uYICtePhTA"><img
                                                src="<?= base_url() ?>assets/impimages/youtub.png" alt="Snow" class="botlink3"></img></a>
                        </div>
                </div>
        </main>