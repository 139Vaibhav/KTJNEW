<div id="form">
	<form>
		<h1>Your team has been registered.</h1>
		<h2>Your Team-id is <?= $teamid ?></h2>
		<h3 style="color:red">Please note it for future reference.</h3>
		<div><a href="https://ktj.in">Explore KTJ.</a></div>

	</form>
</div> 