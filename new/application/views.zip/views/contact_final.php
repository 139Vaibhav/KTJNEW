<body>

                    <div class="slider3d__item">
                        <section class="team-mobile text-center" id="team">
                            <div class="container-team">
                                <div class="row">
                                    <div class="container">
                                        <div class="col-xs-3 col-xs-offset-figure">
                                            <a href="#popup-heads">
                                                <div class="figure-heads">
                                                    <div class="figure-heads-container">
                                                        <div class="figure-heads-heading card-text">
                                                            Executive Heads
                                                        </div>
                                                    </div>
                                                </div>
                                            </a>
                                        </div>
                                        <div class="col-xs-3">
                                            <a href="#popup-finance">
                                                <div class="figure-finance">
                                                    <div class="figure-finance-container">
                                                        <div class="figure-finance-heading card-text">
                                                            Finance Heads
                                                        </div>
                                                    </div>
                                                </div>
                                            </a>

                                        </div>
                                        <div class="col-xs-3">
                                            <a href="#popup-spons">
                                                <div class="figure-sponsorship">
                                                    <div class="figure-sponsorship-container">
                                                        <div class="figure-sponsorship-heading card-text">
                                                            Sponsorship Heads
                                                        </div>
                                                    </div>
                                                </div>
                                            </a>

                                        </div>


                                    </div>
                                </div>
                                <br><br>
                                <div class="row">
                                    <div class="container">

                                        <div class="col-xs-3 col-xs-offset-figure">
                                            <a href="#popup-events">
                                                <div class="figure-events">
                                                    <div class="figure-events-container">
                                                        <div class="figure-events-heading card-text">
                                                            Events Heads
                                                        </div>
                                                    </div>
                                                </div>
                                            </a>

                                        </div>
                                        <div class="col-xs-6 container-team-mobile">
                                            <div class="heading">
                                                <h1 class="heading text-center" id="teamsHeading-mobile">
                                                    TEAMS
                                                </h1>
                                            </div>
                                        </div>




                                    </div>
                                </div>
                                <br><br>
                                <div class="row">
                                    <div class="container">
                                        <div class="col-xs-3 col-xs-offset-figure">
                                            <a href="#popup-web">
                                                <div class="figure-web">
                                                    <div class="figure-web-container">
                                                        <div class="figure-web-heading card-text">
                                                            Web Heads
                                                        </div>
                                                    </div>
                                                </div>
                                            </a>
                                        </div>
                                        <div class="col-xs-3">
                                            <a href="#popup-design">
                                                <div class="figure-design">
                                                    <div class="figure-design-container">
                                                        <div class="figure-design-heading card-text">
                                                            Design Heads
                                                        </div>
                                                    </div>
                                                </div>
                                            </a>

                                        </div>
                                        <div class="col-xs-3">
                                            <a href="#popup-publicity">
                                                <div class="figure-publicity">
                                                    <div class="figure-publicity-container">
                                                        <div class="figure-publicity-heading card-text">
                                                            Media,Publicity & Overseas Heads
                                                        </div>
                                                    </div>
                                                </div>
                                            </a>

                                        </div>


                                    </div>
                                </div>
                            </div>
                        </section>


                        <section class="team text-center" id="team">
                            <div class="container-team">
                                <div class="heading">
                                    <h1 class="heading text-center" id="teamsHeading">
                                        TEAMS
                                    </h1>
                                </div>
                                <div class="row">
                                    <div class="container">
                                        <div class="col-xs-2 col-xs-offset-2">
                                            <a href="#popup-heads">
                                                <div class="figure-heads">
                                                    <div class="figure-heads-container">
                                                        <div class="figure-heads-heading card-text">
                                                            Executive Heads
                                                        </div>
                                                    </div>
                                                </div>
                                            </a>
                                        </div>
                                        <div class="col-xs-2">
                                            <a href="#popup-finance">
                                                <div class="figure-finance">
                                                    <div class="figure-finance-container">
                                                        <div class="figure-finance-heading card-text">
                                                            finance Heads
                                                        </div>
                                                    </div>
                                                </div>
                                            </a>

                                        </div>
                                        <div class="col-xs-2">
                                            <a href="#popup-spons">
                                                <div class="figure-sponsorship">
                                                    <div class="figure-sponsorship-container">
                                                        <div class="figure-sponsorship-heading card-text">
                                                            Sponsorship Heads
                                                        </div>
                                                    </div>
                                                </div>
                                            </a>

                                        </div>

                                        <div class="col-xs-2">
                                            <a href="#popup-events">
                                                <div class="figure-events">
                                                    <div class="figure-events-container">
                                                        <div class="figure-events-heading card-text">
                                                            Events Heads
                                                        </div>
                                                    </div>
                                                </div>
                                            </a>

                                        </div>
                                    </div>
                                </div>
                                <br><br>
                                <div class="row">
                                    <div class="container">
                                        <div class="col-xs-2 col-xs-offset-3">
                                            <a href="#popup-web">
                                                <div class="figure-web">
                                                    <div class="figure-web-container">
                                                        <div class="figure-web-heading card-text">
                                                            Web Heads
                                                        </div>
                                                    </div>
                                                </div>
                                            </a>

                                        </div>
                                        <div class="col-xs-2">
                                            <a href="#popup-design">
                                                <div class="figure-design">
                                                    <div class="figure-design-container">
                                                        <div class="figure-design-heading card-text">
                                                            Design Heads
                                                        </div>
                                                    </div>
                                                </div>
                                            </a>

                                        </div>

                                        <div class="col-xs-2">
                                            <a href="#popup-publicity">
                                                <div class="figure-publicity">
                                                    <div class="figure-publicity-container">
                                                        <div class="figure-publicity-heading card-text">
                                                            Media,Publicity & Overseas Heads
                                                        </div>
                                                    </div>
                                                </div>
                                            </a>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </section>
                    </div>

        <div class="popup" id="popup-spons">
            <div class="popup-content">
                <br><br>
                <a href="#team" class="popup-close">&times;</a>
                <div class="popup-heading text-center">
                    Sponsorship Team Heads
                </div>
                <div class="popup-container">
                    <div class="popup-container-card-spons-one">
                        <div class="popup-sponsorship">
                            <div class="popup-sponsorship-container">
                                <div class="row">
                                    <div class="container">
                                        <h3>Shivam Shahi</h3>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="container">
                                        <div class="col-xs-4">
                                            <a href="https://m.facebook.com/shivam.shahi.560" target="_blank"><img src="assets\css\team\spons\fb.png"></a>
                                        </div>
                                        <div class="col-xs-4">
                                            <a href="https://www.linkedin.com/in/shivam-3b3590163/"><img src="assets\css\team\spons\linked.png"></a>
                                        </div>
                                        <div class="col-xs-4">
                                            <a href="https://mail.google.com/mail/?view=cm&fs=1&to=shivam.s@ktj.in&su=Reason%20for%20contacting:-" target="_blank"><img src="assets\css\team\spons\mail.png"></a>
                                        </div>
                                    </div>

                                </div>

                            </div>
                        </div>
                    </div>

                    <div class="popup-container-card-spons-two">
                        <div class="popup-sponsorship">
                            <div class="popup-sponsorship-container">
                                <div class="row">
                                    <div class="container">
                                        <h3>Deepak Mardi</h3>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="container">
                                        <div class="col-xs-4">
                                            <a href="https://www.facebook.com/deepak.mardi.1920" target="_blank"><img src="assets\css\team\spons\fb.png"></a>
                                        </div>
                                        <div class="col-xs-4">
                                            <a href="https://www.linkedin.com/in/deepak-mardi-659822158" target="_blank"><img src="assets\css\team\spons\linked.png"></a>
                                        </div>
                                        <div class="col-xs-4">
                                            <a href="https://mail.google.com/mail/?view=cm&fs=1&to=deepak.mardi@ktj.in&su=Reason%20for%20contacting:-" target="_blank"><img src="assets\css\team\spons\mail.png"></a>
                                        </div>
                                    </div>

                                </div>

                            </div>
                        </div>

                    </div>
                    <br class="popup-break">
                    <div class="popup-container-card-spons-three">
                        <div class="popup-sponsorship">
                            <div class="popup-sponsorship-container">
                                <div class="row">
                                    <div class="container">
                                        <h3>Parth Lohomi</h3>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="container">
                                        <div class="col-xs-4">
                                            <a href="https://www.facebook.com/lohomiJi" target="_blank"><img src="assets\css\team\spons\fb.png"></a>
                                        </div>
                                        <div class="col-xs-4">
                                            <a href="https://www.linkedin.com/in/parth-lohomi-6290ba158/" target="_blank"><img src="assets\css\team\spons\linked.png"></a>
                                        </div>
                                        <div class="col-xs-4">
                                            <a href="https://mail.google.com/mail/?view=cm&fs=1&to=parth.lohomi@ktj.in&su=Reason%20for%20contacting:-" target="_blank"><img src="assets\css\team\spons\mail.png"></a>
                                        </div>
                                    </div>

                                </div>

                            </div>
                        </div>

                    </div>
                     <div class="popup-container-card-spons-four">
                        <div class="popup-sponsorship">
                            <div class="popup-sponsorship-container">
                                <div class="row">
                                    <div class="container">
                                        <h3>Anurag Porte</h3>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="container">
                                        <div class="col-xs-4">
                                            <a href="https://www.facebook.com/anurag.porte" target="_blank"><img src="assets\css\team\spons\fb.png"></a>
                                        </div>
                                        <div class="col-xs-4">
                                            <a href="https://www.linkedin.com/in/anurag-porte-12a61316b/?originalSubdomain=in" target="_blank"><img src="assets\css\team\spons\linked.png"></a>
                                        </div>
                                        <div class="col-xs-4">
                                            <a href="https://mail.google.com/mail/?view=cm&fs=1&to=anurag.porte@ktj.in&su=Reason%20for%20contacting:-" target="_blank"><img src="assets\css\team\spons\mail.png"></a>
                                        </div>
                                    </div>

                                </div>

                            </div>
                        </div>

                    </div>
                    <br class="popup-break">
                    <div class="popup-container-card-spons-five">
                        <div class="popup-sponsorship">
                            <div class="popup-sponsorship-container">
                                <div class="row">
                                    <div class="container">
                                        <h3>Yash Goyal</h3>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="container">
                                        <div class="col-xs-4">
                                            <a href="https://www.facebook.com/m.me.yash" target="_blank"><img src="assets\css\team\spons\fb.png"></a>
                                        </div>
                                        <div class="col-xs-4">
                                            <a href="https://www.linkedin.com/in/yg1998/" target="_blank"><img src="assets\css\team\spons\linked.png"></a>
                                        </div>
                                        <div class="col-xs-4">
                                            <a href="https://mail.google.com/mail/?view=cm&fs=1&to=yash.goyal@ktj.in&su=Reason%20for%20contacting:-" target="_blank"><img src="assets\css\team\spons\mail.png"></a>
                                        </div>
                                    </div>

                                </div>

                            </div>
                        </div>

                    </div>


                </div>
            </div>
        </div>
        <div class="popup" id="popup-web">
            <div class="popup-content">
                <br><br>
                <a href="#team" class="popup-close">&times;</a>
                <div class="popup-heading text-center">
                    Web Team
                </div>
                <div class="popup-container">
                    <div class="popup-container-card-one">
                        <div class="popup-web">
                            <div class="popup-web-container">
                                <div class="row">
                                    <div class="container">
                                        <h3>Anand Mani Tripathi</h3>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="container">
                                        <div class="col-xs-4">
                                            <a href="https://www.facebook.com/anandmani.tripathi.79" target="_blank"><img src="assets\css\team\spons\fb.png"></a>
                                        </div>
                                        <div class="col-xs-4">
                                            <a href="https://in.linkedin.com/in/anand-mani-tripathi-1aa18b181" target="_blank"><img src="assets\css\team\spons\linked.png"></a>
                                        </div>
                                        <div class="col-xs-4">
                                            <a href="https://mail.google.com/mail/?view=cm&fs=1&to=atmanandmani@gmail.com&su=Reason%20for%20contacting:-" target="_blank"><img src="assets\css\team\spons\mail.png"></a>
                                        </div>
                                    </div>

                                </div>

                            </div>
                        </div>

                    </div>
                    <div class="popup-container-card-two">
                        <div class="popup-web">
                            <div class="popup-web-container">
                                <div class="row">
                                    <div class="container">
                                        <h3>Zenil Sanghvi</h3>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="container">
                                        <div class="col-xs-4">
                                            <a href="https://www.facebook.com/zenil.sanghvi" target="_blank"><img src="assets\css\team\spons\fb.png"></a>
                                        </div>
                                        <div class="col-xs-4">
                                            <a href="https://in.linkedin.com/in/zenil-sanghvi-8134bb148" target="_blank"><img src="assets\css\team\spons\linked.png"></a>
                                        </div>
                                        <div class="col-xs-4">
                                            <a href="https://mail.google.com/mail/?view=cm&fs=1&to=zenilrvs@gmail.com&su=Reason%20for%20contacting:-" target="_blank"><img src="assets\css\team\spons\mail.png"></a>
                                        </div>
                                    </div>

                                </div>

                            </div>
                        </div>

                    </div>
                    <br class="popup-break">
                    <div class="popup-container-card-three">
                        <div class="popup-web">
                            <div class="popup-web-container">
                                <div class="row">
                                    <div class="container">
                                        <h3>Arnab Dey</h3>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="container">
                                        <div class="col-xs-4">
                                            <a href="https://www.facebook.com/arnab.dey.92351995" target="_blank"><img src="assets\css\team\spons\fb.png"></a>
                                        </div>
                                        <div class="col-xs-4">
                                            <a href="https://in.linkedin.com/in/arnab-dey-716174148" target="_blank"><img src="assets\css\team\spons\linked.png"></a>
                                        </div>
                                        <div class="col-xs-4">
                                            <a href="https://mail.google.com/mail/?view=cm&fs=1&to=arnab3178@gmail.com&su=Reason%20for%20contacting:-" target="_blank"><img src="assets\css\team\spons\mail.png"></a>
                                        </div>
                                    </div>

                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="popup" id="popup-design">
            <div class="popup-content">
                <br><br>
                <a href="#team" class="popup-close">&times;</a>
                <div class="popup-heading text-center">
                    Design Team
                </div>
                <div class="popup-container">
                    <div class="popup-container-card-one">
                        <div class="popup-design">
                            <div class="popup-design-container">
                                <div class="row">
                                    <div class="container">
                                        <h3>Saurabh Singh</h3>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="container">
                                        <div class="col-xs-4">
                                            <a href="https://www.facebook.com/aurabh.ingh.39" target="_blank"><img src="assets\css\team\spons\fb.png"></a>
                                        </div>
                                        <div class="col-xs-4">
                                            <a href="https://in.linkedin.com/in/saurabh-singh-7a9101151" target="_blank"><img src="assets\css\team\spons\linked.png"></a>
                                        </div>
                                        <div class="col-xs-4">
                                            <a href="https://mail.google.com/mail/?view=cm&fs=1&to=saurabhsinghchahar192@gmail.com&su=Reason%20for%20contacting:-" target="_blank"><img src="assets\css\team\spons\mail.png"></a>
                                        </div>
                                    </div>

                                </div>

                            </div>
                        </div>


                    </div>
                    <div class="popup-container-card-two">
                        <div class="popup-design">
                            <div class="popup-design-container">
                                <div class="row">
                                    <div class="container">
                                        <h3>Akshit Kumar</h3>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="container">
                                        <div class="col-xs-4">
                                            <a href="https://www.facebook.com/akshit2707" target="_blank"><img src="assets\css\team\spons\fb.png"></a>
                                        </div>
                                        <div class="col-xs-4">
                                            <a href="https://in.linkedin.com/in/akshit-kumar-2707a2707" target="_blank"><img src="assets\css\team\spons\linked.png"></a>
                                        </div>
                                        <div class="col-xs-4">
                                            <a href="https://mail.google.com/mail/?view=cm&fs=1&to=akshit2707.iitkgp@gmail.com&su=Reason%20for%20contacting:-" target="_blank"><img src="assets\css\team\spons\mail.png"></a>
                                        </div>
                                    </div>

                                </div>

                            </div>
                        </div>

                    </div>
                    <br class="popup-break">
                    <div class="popup-container-card-three">
                        <div class="popup-design">
                            <div class="popup-design-container">
                                <div class="row">
                                    <div class="container">
                                        <h3>Abhra Saha</h3>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="container">
                                        <div class="col-xs-4">
                                            <a href="https://www.facebook.com/abhra.saha.007" target="_blank"><img src="assets\css\team\spons\fb.png"></a>
                                        </div>
                                        <div class="col-xs-4">
                                            <a href="https://in.linkedin.com/in/abhra-saha-4b0435130" target="_blank"><img src="assets\css\team\spons\linked.png"></a>
                                        </div>
                                        <div class="col-xs-4">
                                            <a href="https://mail.google.com/mail/?view=cm&fs=1&to=abhraiit@gmail.com&su=Reason%20for%20contacting:-" target="_blank"><img src="assets\css\team\spons\mail.png"></a>
                                        </div>
                                    </div>

                                </div>

                            </div>
                        </div>

                    </div>
    
                </div>
            </div>
        </div>
    </div>
    <div class="popup" id="popup-public">
        <div class="popup-content">
            <br><br>
            <a href="#team" class="popup-close">&times;</a>
            <div class="popup-heading text-center">
                public -team
            </div>
            <div class="popup-container">
                <div class="popup-container-card-one">
                    <div class="figure-public">
                        <div class="figure-public-container">
                            <div class="figure-public-heading">
                                public TEAM
                            </div>
                        </div>
                    </div>


                </div>
                <div class="popup-container-card-two">
                    <div class="figure-public">
                        <div class="figure-public-container">
                            <div class="figure-public-heading">
                                public TEAM
                            </div>
                        </div>
                    </div>

                </div>
                <br class="popup-break">
                <div class="popup-container-card-three">
                    <div class="figure-public">
                        <div class="figure-public-container">
                            <div class="figure-public-heading">
                                public TEAM
                            </div>
                        </div>
                    </div>

                </div>
                <div class="popup-container-card-four">
                    <div class="figure-public">
                        <div class="figure-public-container">
                            <div class="figure-public-heading">
                                public TEAM
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
    <div class="popup" id="popup-events">
        <div class="popup-content">
            <br><br>
            <a href="#team" class="popup-close">&times;</a>
            <div class="popup-heading text-center">
                Events Team
            </div>
            <div class="popup-container">
                <div class="popup-container-card-one">
                    <div class="popup-events">
                        <div class="popup-events-container">
                            <div class="row">
                                <div class="container">
                                    <h3>Vidhan Kashyap</h3>
                                </div>
                            </div>
                            <div class="row">
                                <div class="container">
                                    <div class="col-xs-4">
                                        <a href="https://www.facebook.com/vidhan.kashyap.5" target="_blank"><img src="assets\css\team\spons\fb.png"></a>
                                    </div>
                                    <div class="col-xs-4">
                                        <a href="https://www.linkedin.com/in/vidhan-kashyap-739a7b148/" target="_blank"><img src="assets\css\team\spons\linked.png"></a>
                                    </div>
                                    <div class="col-xs-4">
                                        <a href="https://mail.google.com/mail/?view=cm&fs=1&to=vidhan.kashyap@ktj.in&su=Reason%20for%20contacting:-" target="_blank"><img src="assets\css\team\spons\mail.png"></a>
                                    </div>
                                </div>

                            </div>

                        </div>
                    </div>
                </div>
                <div class="popup-container-card-two">
                    <div class="popup-events">
                        <div class="popup-events-container">
                            <div class="row">
                                <div class="container">
                                    <h3>Shivam Ahirwal</h3>
                                </div>
                            </div>
                            <div class="row">
                                <div class="container">
                                    <div class="col-xs-4">
                                        <a href="https://www.facebook.com/shivamthegod" target="_blank"><img src="assets\css\team\spons\fb.png"></a>
                                    </div>
                                    <div class="col-xs-4">
                                        <a href="https://www.linkedin.com/in/shivam-ahirwal-329b5816a/?originalSubdomain=in" target="_blank"><img src="assets\css\team\spons\linked.png"></a>
                                    </div>
                                    <div class="col-xs-4">
                                        <a href="https://mail.google.com/mail/?view=cm&fs=1&to=shivam.ahirwal@ktj.in&su=Reason%20for%20contacting:-" target="_blank"><img src="assets\css\team\spons\mail.png"></a>
                                    </div>
                                </div>

                            </div>

                        </div>
                    </div>

                </div>
                <br class="popup-break">
                <div class="popup-container-card-three">
                    <div class="popup-events">
                        <div class="popup-events-container">
                            <div class="row">
                                <div class="container">
                                    <h3>Swantantra Kumar</h3>
                                </div>
                            </div>
                            <div class="row">
                                <div class="container">
                                    <div class="col-xs-4">
                                        <a href="https://www.facebook.com/swatantra.kumar.1257604" target="_blank"><img src="assets\css\team\spons\fb.png"></a>
                                    </div>
                                    <div class="col-xs-4">
                                        <a href="https://in.linkedin.com/in/swatantra-kumar-499535161" href="_
                                            "><img src="assets\css\team\spons\linked.png"></a>
                                    </div>
                                    <div class="col-xs-4">
                                        <a href="https://mail.google.com/mail/?view=cm&fs=1&to=swatantra.kumar@ktj.in&su=Reason%20for%20contacting:-" target="_blank"><img src="assets\css\team\spons\mail.png"></a>
                                    </div>
                                </div>

                            </div>

                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
    <div class="popup" id="popup-heads">
        <div class="popup-content">
            <br><br>
            <a href="#team" class="popup-close">&times;</a>
            <div class="popup-heading text-center">
                Executive Team Heads
            </div>
            <div class="popup-container">
                <div class="popup-container-card-one">
                    <div class="popup-heads">
                        <div class="popup-heads-container">
                            <div class="row">
                                <div class="container">
                                    <h3>Yogesh Kanik</h3>
                                </div>
                            </div>
                            <div class="row">
                                <div class="container">
                                    <div class="col-xs-4">
                                        <a href="https://www.facebook.com/yogesh.kanik" target="_blank"><img src="assets\css\team\spons\fb.png"></a>
                                    </div>
                                    <div class="col-xs-4">
                                        <a href="https://www.linkedin.com/in/yogesh-kanik-43714015b/" target="
                                            "><img src="assets\css\team\spons\linked.png"></a>
                                    </div>
                                    <div class="col-xs-4">
                                        <a href="https://mail.google.com/mail/?view=cm&fs=1&to=Kanik.yogesh@ktj.in&su=Reason%20for%20contacting:-" target="_blank"><img src="assets\css\team\spons\mail.png"></a>
                                    </div>
                                </div>

                            </div>

                        </div>
                    </div>
                </div>
                <div class="popup-container-card-two">
                    <div class="popup-heads">
                        <div class="popup-heads-container">
                            <div class="row">
                                <div class="container">
                                    <h3>Ninad Patil</h3>
                                </div>
                            </div>
                            <div class="row">
                                <div class="container">
                                    <div class="col-xs-4">
                                        <a href="https://www.facebook.com/ninad.patil.37604" target="_blank"><img src="assets\css\team\spons\fb.png"></a>
                                    </div>
                                    <div class="col-xs-4">
                                        <a href="https://www.linkedin.com/in/ninad-patil-969a35169/" target="_blank"><img src="assets\css\team\spons\linked.png"></a>
                                    </div>
                                    <div class="col-xs-4">
                                        <a href="https://mail.google.com/mail/?view=cm&fs=1&to=ninad.patil@ktj.in&su=Reason%20for%20contacting:-" target="_blank"><img src="assets\css\team\spons\mail.png"></a>
                                    </div>
                                </div>

                            </div>

                        </div>
                    </div>
                </div>
                <br class="popup-break">


            </div>
        </div>
    </div>
    <div class="popup" id="popup-finance">
        <div class="popup-content">
            <br><br>
            <a href="#team" class="popup-close">&times;</a>
            <div class="popup-heading text-center">
                Finance Team Heads
            </div>
            <div class="popup-container">
                <div class="popup-container-card-one">
                    <div class="popup-finance">
                        <div class="popup-finance-container">
                            <div class="row">
                                <div class="container">
                                    <h3>Rishabh Surana</h3>
                                </div>
                            </div>
                            <div class="row">
                                <div class="container">
                                    <div class="col-xs-4">
                                        <a href="https://www.facebook.com/rishabhsurana03" target="_blank"><img src="assets\css\team\spons\fb.png"></a>
                                    </div>
                                    <div class="col-xs-4">
                                        <a href="https://www.linkedin.com/in/rishabh-surana-977747167/" target="_blank"><img src="assets\css\team\spons\linked.png"></a>
                                    </div>
                                    <div class="col-xs-4">
                                        <a href="https://mail.google.com/mail/?view=cm&fs=1&to=rishabh.surana@ktj.in&su=Reason%20for%20contacting:-" target="_blank"><img src="assets\css\team\spons\mail.png"></a>
                                    </div>
                                </div>

                            </div>

                        </div>
                    </div>
                </div>
                <div class="popup-container-card-two">
                    <div class="popup-finance">
                        <div class="popup-finance-container">
                            <div class="row">
                                <div class="container">
                                    <h3>Pratik Desai</h3>
                                </div>
                            </div>
                            <div class="row">
                                <div class="container">
                                    <div class="col-xs-4">
                                        <a href="https://www.facebook.com/pratik.desai.756" target="_blank"><img src="assets\css\team\spons\fb.png"></a>
                                    </div>
                                    <div class="col-xs-4">
                                        <a href="https://www.linkedin.com/in/pratik-desai-11074412a/" target="_blank"><img src="assets\css\team\spons\linked.png"></a>
                                    </div>
                                    <div class="col-xs-4">
                                        <a href="https://mail.google.com/mail/?view=cm&fs=1&to=pratik.desai@ktj.in &su=Reason%20for%20contacting:-" target="_blank"><img src="assets\css\team\spons\mail.png"></a>
                                    </div>
                                </div>

                            </div>

                        </div>
                    </div>
                </div>
                <br class="popup-break">
            </div>
        </div>
    </div>
    <div class="popup" id="popup-pronite">
        <div class="popup-content">
            <br><br>
            <a href="#team" class="popup-close">&times;</a>
            <div class="popup-heading text-center">
                pronite -team
            </div>
            <div class="popup-container">
                <div class="popup-container-card-one">
                    <div class="figure-pronite">
                        <div class="figure-pronite-container">
                            <div class="figure-pronite-heading">
                                pronite TEAM
                            </div>
                        </div>
                    </div>


                </div>
                <div class="popup-container-card-two">
                    <div class="figure-pronite">
                        <div class="figure-pronite-container">
                            <div class="figure-pronite-heading">
                                pronite TEAM
                            </div>
                        </div>
                    </div>

                </div>
                <br class="popup-break">
                <div class="popup-container-card-three">
                    <div class="figure-pronite">
                        <div class="figure-pronite-container">
                            <div class="figure-pronite-heading">
                                pronite TEAM
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
    <div class="popup" id="popup-publicity">
        <div class="popup-content">
            <br><br>
            <a href="#team" class="popup-close">&times;</a>
            <div class="popup-heading text-center">
                Media, Publicity and Overseas Heads
            </div>
            <div class="popup-container">
                <div class="popup-container-card-one">
                    <div class="popup-publicity">
                        <div class="popup-publicity-container">
                            <div class="row">
                                <div class="container">
                                    <h3>Nikhil Chhatri</h3>
                                </div>
                            </div>
                            <div class="row">
                                <div class="container">
                                    <div class="col-xs-4">
                                        <a href="https://www.facebook.com/nikhil.chhatri.79" target="_blank"><img src="assets\css\team\spons\fb.png"></a>
                                    </div>
                                    <div class="col-xs-4">
                                        <a href="https://www.linkedin.com/in/nikhil-chhatri-60a15916b/" target="_blank"><img src="assets\css\team\spons\linked.png"></a>
                                    </div>
                                    <div class="col-xs-4">
                                        <a href="https://mail.google.com/mail/?view=cm&fs=1&to=nikhil.c@ktj.in&su=Reason%20for%20contacting:-" target="_blank"><img src="assets\css\team\spons\mail.png"></a>
                                    </div>
                                </div>

                            </div>

                        </div>
                    </div>

                </div>
                <div class="popup-container-card-two">
                    <div class="popup-publicity">
                        <div class="popup-publicity-container">
                            <div class="row">
                                <div class="container">
                                    <h3>Rupali Kumari</h3>
                                </div>
                            </div>
                            <div class="row">
                                <div class="container">
                                    <div class="col-xs-4">
                                        <a href="https://www.facebook.com/rupali.kumari.3517563" target="_blank"><img src="assets\css\team\spons\fb.png"></a>
                                    </div>
                                    <div class="col-xs-4">
                                        <a href="https://www.linkedin.com/in/rupali-kumari-b0560316b/" target="_blank"><img src="assets\css\team\spons\linked.png"></a>
                                    </div>
                                    <div class="col-xs-4">
                                        <a href="https://mail.google.com/mail/?view=cm&fs=1&to=rupali.kumari@ktj.in&su=Reason%20for%20contacting:-" target="_blank"><img src="assets\css\team\spons\mail.png"></a>
                                    </div>
                                </div>

                            </div>

                        </div>
                    </div>

                </div>
                <br class="popup-break">
            </div>
        </div>
    </div>
