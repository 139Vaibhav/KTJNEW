<!DOCTYPE html>
<html lang="en">
     
     <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    
    
    <title>Events</title>


    <style>
    .a
    {
         text-align: center;
    }

   body
   {
     background: transparent;
   }
    </style>
    </head>
    <body>
       
     <div class="a">
          <h1>Event Genres</h1>
     </div>
     
     
     <div class="container">   
          <div class="row">
               
               
               
               <div class="col s12 m4">
                    <div class="card">
                         <div class="card-image waves-effect waves-block waves-light">
                              <img class="activator" src="https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcTxEOVTcvf8wEI1bGPVZrCVADRvWGpFsVzrowss8S1SuQl_xJjK">
                         </div>
                         <div class="card-content">
                              <span class="card-title activator grey-text text-darken-4">
                                   Genesis
                                   <i class="material-icons right">+</i>
                              </span>
                              
                         </div>
                         <div class="card-reveal">
                              <span class="card-title grey-text text-darken-4">Genesis<i class="material-icons right">X</i></span>
                              <p>Here is some more information about this product that is only revealed once clicked on.</p>
                              Events
                              <ol>
                                   <li>Woodstock</li>
                                   <li>Supply Matrix</li>
                                   <li>Relic Hunter</li>
                              </ol>
                         </div>
                    </div>
               </div>

                    <div class="col s12 m4">
                         <div class="card">
                              <div class="card-image waves-effect waves-block waves-light">
                                   <img class="activator" src="https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcTxEOVTcvf8wEI1bGPVZrCVADRvWGpFsVzrowss8S1SuQl_xJjK">
                              </div>
                              <div class="card-content">
                                   <span class="card-title activator grey-text text-darken-4">
                                        Quizzard
                                        <i class="material-icons right">+</i>
                                   </span>
                                   
                              </div>
                              <div class="card-reveal">
                                   <span class="card-title grey-text text-darken-4">Quizzard<i class="material-icons right">X</i></span>
                                   <p>Here is some more information about this product that is only revealed once clicked on.</p>
                                   Events
                                   <ol>
                                        <li>Tech Quiz</li>
                                        <li>Biz Quiz</li>
                                        <li>Math Olympiad</li>
                                   </ol>
                              </div>
                         </div>
                    </div>


                         <div class="col s12 m4">
                              <div class="card">
                                   <div class="card-image waves-effect waves-block waves-light">
                                        <img class="activator" src="https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcTxEOVTcvf8wEI1bGPVZrCVADRvWGpFsVzrowss8S1SuQl_xJjK">
                                   </div>
                                   <div class="card-content">
                                        <span class="card-title activator grey-text text-darken-4">
                                             Conceptualize
                                             <i class="material-icons right">+</i>
                                        </span>
                                        
                                   </div>
                                   <div class="card-reveal">
                                        <span class="card-title grey-text text-darken-4">Conceptualize<i class="material-icons right">X</i></span>
                                        <p>Here is some more information about this product that is only revealed once clicked on.</p>
                                        Events
                                        <ol>
                                             <li>B Plan</li>
                                             <li>Eureka</li>
                                             <li>Anadigix</li>
                                        </ol>
                                   </div>
                              </div>
                         </div>

                    



   <div class="col s12 m4">
          <div class="card">
             <div class="card-image waves-effect waves-block waves-light">
               <img class="activator" src="https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcTxEOVTcvf8wEI1bGPVZrCVADRvWGpFsVzrowss8S1SuQl_xJjK">
             </div>
             <div class="card-content">
               <span class="card-title activator grey-text text-darken-4">Code Conclave<i class="material-icons right">+</i></span>
               
             </div>
             <div class="card-reveal">
               <span class="card-title grey-text text-darken-4">Code Conclave<i class="material-icons right">X</i></span>
               <p>Here is some more information about this product that is only revealed once clicked on.</p>
               Events
               <ol>
                    <li>Source Code</li>
                    <li>Overnite</li>
                    <li>Code-O-Soccer</li>
               </ol>
             </div>
           </div>
           </div>



           <div class="col s12 m4">
                    <div class="card">
                       <div class="card-image waves-effect waves-block waves-light">
                         <img class="activator" src="https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcTxEOVTcvf8wEI1bGPVZrCVADRvWGpFsVzrowss8S1SuQl_xJjK">
                       </div>
                       <div class="card-content">
                         <span class="card-title activator grey-text text-darken-4">Robotics<i class="material-icons right">+</i></span>
                         
                       </div>
                       <div class="card-reveal">
                         <span class="card-title grey-text text-darken-4">Robotics<i class="material-icons right">X</i></span>
                         <p>Here is some more information about this product that is only revealed once clicked on.</p>
                         Events
                         <ol>
                              <li>Robowar</li>
                              <li>Embetronix</li>
                              <li>DroidBlitz</li>
                         </ol>
                       </div>
                     </div>
                     </div>


                     <div class="col s12 m4">
                         <div class="card">
                              <div class="card-image waves-effect waves-block waves-light">
                                   <img class="activator" src="https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcTxEOVTcvf8wEI1bGPVZrCVADRvWGpFsVzrowss8S1SuQl_xJjK">
                              </div>
                              <div class="card-content">
                                   <span class="card-title activator grey-text text-darken-4">
                                        Mechanize
                                        <i class="material-icons right">+</i>
                                   </span>
                                   
                              </div>
                              <div class="card-reveal">
                                   <span class="card-title grey-text text-darken-4">Mechanize<i class="material-icons right">X</i></span>
                                   <p>Here is some more information about this product that is only revealed once clicked on.</p>
                                   Events
                                   <ol>
                                        <li>Sand Rover</li>
                                        <li>Laws of Motion</li>
                                        <li>Arm of Achelous</li>
                                   </ol>
                              </div>
                         </div>
                    </div>

                    <div class="col s12 m4">
                         <div class="card">
                              <div class="card-image waves-effect waves-block waves-light">
                                   <img class="activator" src="https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcTxEOVTcvf8wEI1bGPVZrCVADRvWGpFsVzrowss8S1SuQl_xJjK">
                              </div>
                              <div class="card-content">
                                   <span class="card-title activator grey-text text-darken-4">
                                        Strategia
                                        <i class="material-icons right">+</i>
                                   </span>
                                   
                              </div>
                              <div class="card-reveal">
                                   <span class="card-title grey-text text-darken-4">Strategia<i class="material-icons right">X</i></span>
                                   <p>Here is some more information about this product that is only revealed once clicked on.</p>
                                   Events
                                   <ol>
                                        <li>Indian Case Challenge</li>
                                   </ol>
                              </div>
                         </div>
                    </div>

                    <div class="col s12 m4">
                         <div class="card">
                              <div class="card-image waves-effect waves-block waves-light">
                                   <img class="activator" src="https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcTxEOVTcvf8wEI1bGPVZrCVADRvWGpFsVzrowss8S1SuQl_xJjK">
                              </div>
                              <div class="card-content">
                                   <span class="card-title activator grey-text text-darken-4">
                                        Industrial Architecture
                                        <i class="material-icons right">+</i>
                                   </span>
                                   
                              </div>
                              <div class="card-reveal">
                                   <span class="card-title grey-text text-darken-4">Industrial Architecture<i class="material-icons right">X</i></span>
                                   <p>Here is some more information about this product that is only revealed once clicked on.</p>
                                   Events
                                   <ol>
                                        <li>Biomimicry</li>
                                   </ol>
                              </div>
                         </div>
                    </div>

                    <div class="col s12 m4">
                         <div class="card">
                              <div class="card-image waves-effect waves-block waves-light">
                                   <img class="activator" src="https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcTxEOVTcvf8wEI1bGPVZrCVADRvWGpFsVzrowss8S1SuQl_xJjK">
                              </div>
                              <div class="card-content">
                                   <span class="card-title activator grey-text text-darken-4">
                                        Tech for Fun
                                        <i class="material-icons right">+</i>
                                   </span>
                                   
                              </div>
                              <div class="card-reveal">
                                   <span class="card-title grey-text text-darken-4">Tech for Fun<i class="material-icons right">X</i></span>
                                   <p>Here is some more information about this product that is only revealed once clicked on.</p>
                                   Events
                                   <ol>
                                        <li>Techquila</li>
                                        <li>Snappit</li>
                                   </ol>
                              </div>
                         </div>
                    </div>
                    <div class="col s12 m4">
                         
                    </div>
                    <div class="col s12 m4">
                         <div class="card">
                              <div class="card-image waves-effect waves-block waves-light">
                                   <img class="activator" src="https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcTxEOVTcvf8wEI1bGPVZrCVADRvWGpFsVzrowss8S1SuQl_xJjK">
                              </div>
                              <div class="card-content">
                                   <span class="card-title activator grey-text text-darken-4">
                                        Game Fest
                                        <i class="material-icons right">+</i>
                                   </span>
                                   
                              </div>
                              <div class="card-reveal">
                                   <span class="card-title grey-text text-darken-4">Game Fest<i class="material-icons right">X</i></span>
                                   <p>Here is some more information about this product that is only revealed once clicked on.</p>
                                   Events
                                   <ol>
                                        <li>Krypton 2.0</li>
                                   </ol>
                              </div>
                         </div>
                    </div>
               



                     <div class="col s12 m4">
                              
                               </div>
   </div>
</div>
    </body>
    </html>