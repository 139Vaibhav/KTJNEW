"use strict"
var subscribeUrl = "http://octrace.us14.list-manage.com/subscribe/post?u=b65c95763e0ae8e0c14e7af0e&amp;id=7e9cf89638";
var email = "octrace@gmail.com";
var countdown = false;
var configDate = "2018 01 01";
var particles = true;