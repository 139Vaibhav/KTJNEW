<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags-->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="icon" href="Kshitij_Logo.png">
          <meta name = "viewport" content = "width = device-width, initial-scale = 1">      
    <script type = "text/javascript"
         src = "https://code.jquery.com/jquery-2.1.1.min.js"></script>           
      <script src = "https://cdnjs.cloudflare.com/ajax/libs/materialize/0.97.3/js/materialize.min.js">
      </script>

    <!-- Title Page-->
    <title>Kshitij - Regstration Page</title>

    <!-- Main CSS-->
      <link href='https://fonts.googleapis.com/css?family=Raleway:200,400,800' rel='stylesheet' type='text/css'>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/5.0.0/normalize.min.css">
    <link rel='stylesheet' href='https://www.marcoguglie.it/Codepen/AnimatedHeaderBg/demo-1/css/demo.css'>    
    <link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/css/select2.min.css" rel="stylesheet" />
		<link rel="stylesheet" href="<?= base_url() ?>assets/css/owl.carousel.min.css">
          <link rel="stylesheet" href="<?= base_url() ?>assets/css/owl.theme.green.min.css">

          <link rel="stylesheet" href="<?= base_url() ?>assets/css/stylecss">

          <script src='https://kit.fontawesome.com/a076d05399.js'></script>

          
          


          <link rel="icon" type="image/png" href="<?= base_url() ?>assets/logincss/images/icons/favicon.ico"/>
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="<?= base_url() ?>assets/logincss/vendor/bootstrap/css/bootstrap.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="<?= base_url() ?>assets/logincss/fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="<?= base_url() ?>assets/logincss/vendor/animate/animate.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="<?= base_url() ?>assets/logincss/vendor/css-hamburgers/hamburgers.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="<?= base_url() ?>assets/logincss/vendor/select2/select2.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="<?= base_url() ?>assets/logincss/css/util.css">
     <link rel="stylesheet" type="text/css" href="<?= base_url() ?>assets/logincss/css/main.css">

    <link href="<?= base_url() ?>assets/main.css" rel="stylesheet" media="all">
    

     <style>
          
          .abcdef
          {
               width: 50%;
               background-color: #e6e6e6;
               border-radius: 200px;
               text-align: center;
               position: relative;
               transform: translateX(50%);
          }

          .abcde
          {
               width: 50%;
               background-color: #e6e6e6;
               border-radius: 200px;
               text-align: center;
               position: relative;
               transform: translateX(3%);
               
          }
          .wrap-input100
          {
               width: 50%;
               position: relative;
               transform: translateX(50%);
          }
          .wrap-input1001
          {
               width: 100% !important;
               position: relative;
               transform: translateX(-4.5%);
               
          }
          .container-login100-form-btn
          {
               width: 50%;
               transform: translateX(50%);
               
          }
          .container-login1001
          {
               width: 100%;
               position: relative;
               left:50%;
               transform: translateX(-40%);
               z-index: -999;
          }

     </style>
      <title>Coming Soon</title>
          <style>
               body{
                    background:transparent;
                    overflow:scroll;
               }
                    
               
               .ayu
               {     
 
                    text-align: center;
               }
               .klo
               {
                    height: 97vh;
                    width: 97vw;
                    border-color: #1b2b39;
               }
               *{
    text-decoration: none;
  }
  
  
.left{
    float: left;
    width: 4%;
    margin: 1% 0% 0% 2%;
}

.right{
    float: right;
    width: 25%;
    margin-top: 1%;
}

.tnavig {
  float:left;
}

.links,.olink {
  float: left;
  font-size: 1.3vw;
  margin-right: 2%;
  padding: 0;
  color: white;
  font-family: 'Open Sans', sans-serif;
  text-shadow: 0 0 1px white,0px 0px 5px black;
  cursor: pointer;
  left: 4%;
  margin: 2% 0% 0% 5%;
}

.links:hover,.blinks:hover
{
  text-shadow: 0 0 5px lightblue,0px 0px 10px lightblue;
}

  .centered{
    margin-top:8%;
    margin-bottom: 4%;
  }
  .logo{
      width:50%;
      height:60%;
      display: block;
      padding: 0px;
      font-style: unset;
      margin:13% 27% 4%;
      clear: both;
  }
  
  .topleft{
    float:left;
    width: 4%;
    top: 0px;
    left: 0px;
    right: 100%;
    margin-left: 2%;
  }
  
  .medium{
      font-size: 7vw;
      padding: 0px;
      margin:0px;
      padding: 0px;
      font-family: 'oswald', cursive,sans-serif;
      color:violet;
      -webkit-text-fill-color: transparent;
      -webkit-text-stroke-width: 2px;
      text-shadow: 0 0 100px violet,0px 0px 25px violet;
  }
  .big{
      padding: 0px;
      margin:0px;
      font-size: 8vw !important;
      font-family: 'oswald', cursive,sans-serif;
      color: violet;
      -webkit-text-fill-color: transparent;
      -webkit-text-stroke-width: 2px;
      text-shadow: 0 0 100px violet,0px 0px 25px violet;
  }
  .theme{
      margin-top:0;
      padding: 0px;
      font-size: 6vw;
      font-family: 'oswald', cursive,sans-serif;
      color: violet;
      -webkit-text-fill-color: transparent;
      -webkit-text-stroke-width: 2px;
      text-shadow: 0 0 100px violet,0px 0px 25px violet;
  }
  
  .soon{
    color:white;
    text-align: center;
    font-size:2.5vw;
    padding: 2% 8% 0% 6%;
    margin:0px 0px 0px 6%;
    animation: glitchy 4s alternate 1s infinite;
  }
  @keyframes glitchy {
   25%
   {
    text-shadow: 0 0 5px lightblue,0px 0px 5px lightblue;
   }
   50%
   {
    text-shadow: 0 0 5px lightblue,0px 0px 25px lightblue;
   }
   75%
   {
    text-shadow: 0 0 5px lightblue,0px 0px 5px lightblue;
   }
   100%
   {
    text-shadow: 0 0 5px lightblue,0px 0px 25px lightblue;
   }
  }

  .bleft,.bright {
    width: 20%;
    font-size: 1.3vw;
    display: inline-block;
    text-decoration: none;
    color: white !important;
    margin: 0% 0% 0% .5%;
    color: white;
    font-family: 'Open Sans', sans-serif;
    text-shadow: 0 0 1px white,0px 0px 5px black;
    cursor: pointer;
    position: absolute;
    top: 94%;
  }

  .bright{
    left:85%;
  }

  .bottom{
    display: inline;
    margin: 0% 0%;
    position: absolute;
    top: 95%;
    left: 63%;
    transform: translate(-50%, -50%);
  }
  
  .footer{
    width:40%;
    margin:0px 40% 0% 30%;
    position: relative;
    text-align: center;
  }
  
  .middle {
    margin-top:16%;
  }
  


  .navig {
    display: none;
  }

  body {
    font-family: 'Lato', sans-serif;
  }
  
  .overlay {
    height: 0%;
    width: 100%;
    position: fixed;
    z-index: 1;
    top: 0;
    left: 0;
    background-color: rgb(0,0,0);
    background-color: rgba(0,0,0, 0.9);
    overflow-y: hidden;
    transition: 0.5s;
  }
  .olinks {
    font-size: 12px;
  }
  .overlay-content {
    font-size: 12px;
    position: relative;
    top: 8%;
    width: 100%;
    text-align: center;
    margin-top: 30px;
    left: -2%;
  }
  
  .overlay a {
    padding: 8px;
    text-decoration: none;
    font-size: 24px;
    color: #818181;
    display: block;
    transition: 0.3s;
  }
  
  .overlay a:hover, .overlay a:focus {
    color: #f1f1f1;
  }
  
  .overlay .closebtn {
    position: absolute;
    top: 20px;
    right: 45px;
    font-size: 24px;
  }

  .botlink1 {
    width: 7%;
    margin: 0% 2%;
  }
  
  .botlink2 {
    width: 7%;
    margin: 0% 2%;
  }

  .botlink3 {
    width: 8%;
    margin: 0% 2%;
    padding-bottom:1%;
  }

  @media screen and (max-height: 480px) {
    .overlay {overflow-y: auto;}
    .overlay a {font-size: 20px}
    .overlay .closebtn {
    font-size: 40px;
    top: 15px;
    right: 35px;
    }
  }

  @media screen and (max-width: 600px) {
    .navig {
      display: block;
      color: white;
    }
    .links{
      display: none;
    }
    .left {
      top: 4%;
      width: 8%;
    }
    .right {
      top: 4%;
      width: 50%;
    }
    .middle {
      margin-top: 50%;
      transform: translate(0%, 0%);
    }
    .logo{
      width: 80%;
      margin-left: 12%;
    }
    .soon {
      width: 100%;
      margin-left: -4%;
      font-size: 150%;
    }
    .bottom {
      left: 57%;
    }
    .botlink1,.botlink2 {
      width: 20%;
    }
    .botlink3 {
      width: 23%;
    }
  }



















  html {
    height: 100%;
    background: radial-gradient(#1b2735 0%, #090a0f 100%);
  }
  
  #stars {
    width: 1px;
    height: 1px;
    background: transparent;
    box-shadow: 952px 255px #FFF , 103px 1952px #FFF , 485px 1038px #FFF , 776px 1327px #FFF , 773px 301px #FFF , 1047px 1527px #FFF , 1991px 1969px #FFF , 1654px 1410px #FFF , 1051px 1688px #FFF , 1264px 1151px #FFF , 65px 1263px #FFF , 1391px 1757px #FFF , 1606px 1843px #FFF , 335px 1562px #FFF , 1333px 1942px #FFF , 678px 687px #FFF , 767px 1147px #FFF , 405px 782px #FFF , 986px 1344px #FFF , 951px 988px #FFF , 1428px 1006px #FFF , 1071px 1837px #FFF , 201px 1150px #FFF , 660px 211px #FFF , 808px 1717px #FFF , 1360px 1868px #FFF , 1674px 1250px #FFF , 1257px 945px #FFF , 308px 109px #FFF , 1030px 897px #FFF , 684px 1279px #FFF , 1392px 1890px #FFF , 239px 1198px #FFF , 719px 754px #FFF , 1017px 913px #FFF , 861px 283px #FFF , 1703px 247px #FFF , 1252px 1221px #FFF , 1982px 1952px #FFF , 1772px 1416px #FFF , 770px 1562px #FFF , 978px 1863px #FFF , 364px 995px #FFF , 256px 254px #FFF , 372px 1242px #FFF , 597px 857px #FFF , 799px 1233px #FFF , 1583px 990px #FFF , 57px 1145px #FFF , 284px 1645px #FFF , 1958px 691px #FFF , 686px 1806px #FFF , 739px 988px #FFF , 1776px 1730px #FFF , 1947px 33px #FFF , 1613px 958px #FFF , 1516px 1927px #FFF , 1705px 1152px #FFF , 1138px 1699px #FFF , 260px 972px #FFF , 1709px 225px #FFF , 636px 1520px #FFF , 1866px 1104px #FFF , 151px 1990px #FFF , 1790px 1191px #FFF , 1093px 1977px #FFF , 341px 316px #FFF , 1255px 676px #FFF , 1954px 119px #FFF , 299px 280px #FFF , 287px 68px #FFF , 1300px 360px #FFF , 278px 1083px #FFF , 1124px 913px #FFF , 887px 512px #FFF , 631px 107px #FFF , 1491px 572px #FFF , 1382px 831px #FFF , 1276px 566px #FFF , 1817px 710px #FFF , 1155px 1307px #FFF , 1336px 1298px #FFF , 107px 863px #FFF , 37px 1816px #FFF , 856px 351px #FFF , 1886px 205px #FFF , 1631px 67px #FFF , 689px 787px #FFF , 1959px 1995px #FFF , 1119px 1967px #FFF , 1134px 1535px #FFF , 951px 666px #FFF , 1290px 62px #FFF , 347px 1634px #FFF , 529px 376px #FFF , 1511px 98px #FFF , 1355px 1547px #FFF , 1583px 117px #FFF , 479px 321px #FFF , 1205px 1013px #FFF , 1073px 853px #FFF , 506px 19px #FFF , 80px 1244px #FFF , 353px 345px #FFF , 1785px 87px #FFF , 1825px 724px #FFF , 1563px 8px #FFF , 1007px 1718px #FFF , 1962px 1184px #FFF , 1246px 1365px #FFF , 267px 1086px #FFF , 1222px 475px #FFF , 1154px 723px #FFF , 1733px 728px #FFF , 1132px 54px #FFF , 1685px 1402px #FFF , 929px 1602px #FFF , 166px 1137px #FFF , 1004px 551px #FFF , 1034px 203px #FFF , 1715px 1363px #FFF , 1939px 1807px #FFF , 1370px 1725px #FFF , 357px 1564px #FFF , 860px 1477px #FFF , 1137px 264px #FFF , 983px 1556px #FFF , 1785px 1205px #FFF , 1613px 1788px #FFF , 724px 988px #FFF , 1051px 26px #FFF , 118px 1955px #FFF , 888px 1827px #FFF , 1094px 335px #FFF , 505px 356px #FFF , 1781px 1339px #FFF , 1055px 842px #FFF , 1981px 1509px #FFF , 1786px 1825px #FFF , 719px 576px #FFF , 311px 1260px #FFF , 1270px 1771px #FFF , 213px 1137px #FFF , 168px 1205px #FFF , 1752px 1232px #FFF , 1330px 805px #FFF , 513px 1101px #FFF , 1185px 76px #FFF , 1848px 55px #FFF , 687px 208px #FFF , 193px 640px #FFF , 179px 142px #FFF , 1030px 177px #FFF , 1725px 488px #FFF , 483px 161px #FFF , 1004px 1770px #FFF , 1560px 1469px #FFF , 519px 1520px #FFF , 987px 233px #FFF , 263px 982px #FFF , 528px 1775px #FFF , 220px 538px #FFF , 1395px 1381px #FFF , 1559px 132px #FFF , 94px 1671px #FFF , 1485px 351px #FFF , 1161px 612px #FFF , 1282px 10px #FFF , 446px 432px #FFF , 1072px 1096px #FFF , 1814px 1832px #FFF , 163px 689px #FFF , 802px 351px #FFF , 1279px 1246px #FFF , 477px 143px #FFF , 766px 7px #FFF , 1140px 241px #FFF , 457px 481px #FFF , 299px 1039px #FFF , 380px 913px #FFF , 1456px 760px #FFF , 406px 257px #FFF , 1206px 1448px #FFF , 1321px 106px #FFF , 719px 1354px #FFF , 1609px 526px #FFF , 1316px 1982px #FFF , 1925px 1292px #FFF , 1450px 761px #FFF , 410px 157px #FFF , 1657px 1479px #FFF , 1727px 232px #FFF , 1656px 1697px #FFF , 1087px 324px #FFF , 926px 1081px #FFF , 1114px 1604px #FFF , 1545px 133px #FFF , 886px 59px #FFF , 1993px 1744px #FFF , 1921px 1032px #FFF , 454px 1721px #FFF , 135px 1942px #FFF , 210px 1208px #FFF , 725px 1421px #FFF , 853px 1934px #FFF , 1062px 1933px #FFF , 1220px 167px #FFF , 1280px 1186px #FFF , 210px 617px #FFF , 1216px 882px #FFF , 60px 1180px #FFF , 379px 1074px #FFF , 1943px 1808px #FFF , 532px 314px #FFF , 747px 1092px #FFF , 1972px 598px #FFF , 911px 953px #FFF , 1251px 256px #FFF , 768px 1608px #FFF , 1966px 1136px #FFF , 532px 1032px #FFF , 126px 210px #FFF , 1586px 1202px #FFF , 1576px 392px #FFF , 1133px 141px #FFF , 667px 1625px #FFF , 1193px 1872px #FFF , 1492px 1866px #FFF , 826px 1617px #FFF , 676px 1397px #FFF , 1312px 1338px #FFF , 1044px 714px #FFF , 719px 1655px #FFF , 1459px 1147px #FFF , 1126px 618px #FFF , 1749px 1557px #FFF , 267px 768px #FFF , 1416px 1865px #FFF , 1685px 839px #FFF , 270px 100px #FFF , 276px 1666px #FFF , 60px 1872px #FFF , 1830px 1183px #FFF , 1539px 330px #FFF , 495px 102px #FFF , 1532px 1959px #FFF , 955px 892px #FFF , 727px 1129px #FFF , 1092px 939px #FFF , 505px 1347px #FFF , 139px 89px #FFF , 106px 617px #FFF , 1215px 1217px #FFF , 508px 1828px #FFF , 1968px 43px #FFF , 1584px 663px #FFF , 1101px 1258px #FFF , 1033px 871px #FFF , 997px 799px #FFF , 199px 2px #FFF , 145px 1995px #FFF , 1772px 497px #FFF , 148px 827px #FFF , 723px 1502px #FFF , 1999px 196px #FFF , 1067px 1466px #FFF , 1864px 1533px #FFF , 813px 647px #FFF , 23px 77px #FFF , 842px 1252px #FFF , 1947px 1123px #FFF , 245px 804px #FFF , 1013px 1359px #FFF , 1195px 1535px #FFF , 728px 84px #FFF , 1625px 1316px #FFF , 362px 691px #FFF , 742px 1496px #FFF , 137px 1065px #FFF , 1575px 1143px #FFF , 1579px 1513px #FFF , 218px 1943px #FFF , 763px 1734px #FFF , 710px 621px #FFF , 741px 1260px #FFF , 305px 429px #FFF , 1372px 1079px #FFF , 851px 92px #FFF , 180px 804px #FFF , 1964px 294px #FFF , 891px 1299px #FFF , 1859px 1692px #FFF , 1660px 1945px #FFF , 673px 1193px #FFF , 1133px 211px #FFF , 671px 270px #FFF , 736px 1100px #FFF , 365px 394px #FFF , 402px 827px #FFF , 985px 351px #FFF , 258px 1028px #FFF , 1007px 930px #FFF , 256px 739px #FFF , 590px 1545px #FFF , 606px 1988px #FFF , 552px 159px #FFF , 325px 566px #FFF , 261px 1640px #FFF , 1719px 1781px #FFF , 193px 1952px #FFF , 620px 290px #FFF , 947px 558px #FFF , 339px 109px #FFF , 790px 75px #FFF , 1615px 596px #FFF , 1038px 1041px #FFF , 1612px 774px #FFF , 370px 1126px #FFF , 1091px 1666px #FFF , 129px 1093px #FFF , 141px 475px #FFF , 1085px 1223px #FFF , 1117px 751px #FFF , 1430px 1705px #FFF , 571px 82px #FFF , 1094px 418px #FFF , 319px 1019px #FFF , 570px 774px #FFF , 1318px 751px #FFF , 327px 421px #FFF , 1258px 511px #FFF , 1807px 741px #FFF , 1629px 1005px #FFF , 1100px 1386px #FFF , 1771px 1413px #FFF , 1316px 288px #FFF , 1248px 1331px #FFF , 1524px 221px #FFF , 1576px 1391px #FFF , 1090px 983px #FFF , 1556px 1366px #FFF , 1453px 1604px #FFF , 502px 991px #FFF , 1214px 1479px #FFF , 561px 650px #FFF , 939px 168px #FFF , 188px 1058px #FFF , 1885px 697px #FFF , 1067px 1732px #FFF , 296px 1099px #FFF , 779px 740px #FFF , 37px 1436px #FFF , 355px 878px #FFF , 1063px 107px #FFF , 977px 1762px #FFF , 1052px 744px #FFF , 1501px 235px #FFF , 84px 1006px #FFF , 1082px 1672px #FFF , 1810px 431px #FFF , 984px 1695px #FFF , 393px 991px #FFF , 1911px 1854px #FFF , 1724px 58px #FFF , 1460px 1406px #FFF , 674px 1268px #FFF , 865px 1852px #FFF , 1178px 1223px #FFF , 1805px 119px #FFF , 1321px 183px #FFF , 788px 550px #FFF , 605px 1076px #FFF , 511px 1872px #FFF , 1498px 209px #FFF , 1735px 1682px #FFF , 745px 1780px #FFF , 1955px 790px #FFF , 852px 653px #FFF , 508px 521px #FFF , 407px 197px #FFF , 1688px 597px #FFF , 726px 250px #FFF , 760px 1443px #FFF , 208px 1781px #FFF , 700px 1378px #FFF , 905px 609px #FFF , 854px 1954px #FFF , 1109px 1509px #FFF , 66px 1394px #FFF , 282px 985px #FFF , 323px 1163px #FFF , 1540px 1341px #FFF , 45px 1286px #FFF , 807px 921px #FFF , 790px 1833px #FFF , 1633px 726px #FFF , 1330px 1894px #FFF , 1591px 1802px #FFF , 1350px 230px #FFF , 1320px 1373px #FFF , 1100px 273px #FFF , 1175px 1679px #FFF , 557px 1229px #FFF , 1700px 1691px #FFF , 725px 560px #FFF , 1589px 1593px #FFF , 1459px 1914px #FFF , 175px 2px #FFF , 960px 1110px #FFF , 874px 80px #FFF , 548px 402px #FFF , 958px 1124px #FFF , 1419px 1179px #FFF , 909px 366px #FFF , 291px 21px #FFF , 914px 714px #FFF , 653px 947px #FFF , 1205px 1501px #FFF , 117px 193px #FFF , 140px 1161px #FFF , 99px 259px #FFF , 1499px 211px #FFF , 367px 1439px #FFF , 1146px 35px #FFF , 295px 1104px #FFF , 1338px 606px #FFF , 212px 1605px #FFF , 994px 492px #FFF , 1922px 1798px #FFF , 661px 1118px #FFF , 1271px 1746px #FFF , 560px 1761px #FFF , 684px 1603px #FFF , 1936px 449px #FFF , 1279px 1478px #FFF , 965px 1810px #FFF , 1919px 469px #FFF , 1277px 1438px #FFF , 1916px 907px #FFF , 282px 930px #FFF , 1759px 501px #FFF , 883px 1672px #FFF , 991px 855px #FFF , 1502px 1533px #FFF , 52px 875px #FFF , 1883px 1030px #FFF , 364px 1541px #FFF , 68px 597px #FFF , 1692px 1046px #FFF , 1885px 441px #FFF , 1426px 1929px #FFF , 466px 1591px #FFF , 37px 1770px #FFF , 1377px 209px #FFF , 465px 1490px #FFF , 638px 942px #FFF , 1614px 223px #FFF , 12px 1066px #FFF , 1724px 362px #FFF , 474px 513px #FFF , 999px 863px #FFF , 1292px 1008px #FFF , 993px 48px #FFF , 54px 382px #FFF , 34px 1114px #FFF , 552px 896px #FFF , 868px 441px #FFF , 1600px 1729px #FFF , 1577px 55px #FFF , 1989px 606px #FFF , 645px 656px #FFF , 1766px 352px #FFF , 302px 550px #FFF , 144px 1091px #FFF , 400px 1163px #FFF , 1178px 1283px #FFF , 1638px 105px #FFF , 1595px 1551px #FFF , 369px 1857px #FFF , 1516px 411px #FFF , 663px 297px #FFF , 701px 141px #FFF , 496px 1854px #FFF , 1154px 1300px #FFF , 1579px 102px #FFF , 1071px 1958px #FFF , 916px 1268px #FFF , 1130px 1648px #FFF , 1352px 1342px #FFF , 1478px 1603px #FFF , 46px 1999px #FFF , 1062px 1038px #FFF , 1766px 877px #FFF , 770px 712px #FFF , 317px 1402px #FFF , 1699px 188px #FFF , 227px 318px #FFF , 1976px 142px #FFF , 1486px 502px #FFF , 104px 1010px #FFF , 1052px 1505px #FFF , 1045px 795px #FFF , 217px 650px #FFF , 361px 828px #FFF , 615px 1133px #FFF , 1277px 619px #FFF , 1958px 635px #FFF , 1194px 1345px #FFF , 863px 1878px #FFF , 1722px 381px #FFF , 657px 223px #FFF , 585px 95px #FFF , 1904px 1278px #FFF , 850px 829px #FFF , 73px 1113px #FFF , 411px 1198px #FFF , 1941px 752px #FFF , 1748px 761px #FFF , 1022px 1321px #FFF , 1818px 107px #FFF , 1273px 819px #FFF , 1497px 1321px #FFF , 1472px 1372px #FFF , 290px 1292px #FFF , 337px 309px #FFF , 1250px 684px #FFF , 1788px 1520px #FFF , 1433px 1960px #FFF , 1179px 707px #FFF , 107px 958px #FFF , 886px 497px #FFF , 864px 173px #FFF , 174px 909px #FFF , 1851px 310px #FFF , 675px 144px #FFF , 143px 1028px #FFF , 36px 1960px #FFF , 322px 1664px #FFF , 749px 170px #FFF , 1183px 1661px #FFF , 229px 471px #FFF , 1714px 1866px #FFF , 1882px 1524px #FFF , 1475px 1399px #FFF , 906px 1991px #FFF , 485px 226px #FFF , 75px 1842px #FFF , 866px 560px #FFF , 235px 807px #FFF , 1707px 996px #FFF , 744px 208px #FFF , 1857px 1325px #FFF , 1279px 1027px #FFF , 1174px 1416px #FFF , 1684px 950px #FFF , 270px 122px #FFF , 63px 1090px #FFF , 771px 723px #FFF , 1146px 1486px #FFF , 1243px 502px #FFF , 1578px 942px #FFF , 113px 1809px #FFF , 380px 678px #FFF , 1531px 325px #FFF , 366px 1099px #FFF , 826px 445px #FFF , 431px 269px #FFF , 454px 1861px #FFF , 1907px 151px #FFF , 208px 1185px #FFF , 1409px 752px #FFF , 687px 1787px #FFF , 333px 1198px #FFF , 1545px 870px #FFF , 1225px 1225px #FFF , 575px 1673px #FFF , 236px 168px #FFF , 1030px 749px #FFF , 1419px 640px #FFF , 250px 1214px #FFF , 1322px 792px #FFF , 39px 565px #FFF , 1366px 799px #FFF , 873px 1920px #FFF , 1255px 430px #FFF , 1644px 1109px #FFF , 1534px 608px #FFF , 1111px 1120px #FFF , 737px 1591px #FFF , 1661px 1852px #FFF , 539px 1858px #FFF , 550px 1906px #FFF , 979px 513px #FFF , 289px 558px #FFF , 220px 157px #FFF , 172px 744px #FFF , 1807px 1832px #FFF , 708px 10px #FFF , 1273px 1231px #FFF , 1956px 1590px #FFF , 250px 1134px #FFF , 1658px 1662px #FFF , 1282px 1683px #FFF , 271px 894px #FFF , 1221px 1283px #FFF , 1928px 891px #FFF , 955px 924px #FFF , 1051px 197px #FFF , 863px 26px #FFF , 306px 365px #FFF , 1028px 621px #FFF , 1737px 877px #FFF , 91px 247px #FFF , 918px 20px #FFF , 1944px 1264px #FFF , 566px 415px #FFF , 599px 1178px #FFF , 1961px 891px #FFF , 643px 1584px #FFF , 913px 1835px #FFF , 945px 1658px #FFF , 1167px 666px #FFF , 515px 299px #FFF , 557px 246px #FFF , 74px 874px #FFF , 833px 101px #FFF , 671px 435px #FFF , 124px 430px #FFF , 740px 992px #FFF , 323px 1552px #FFF , 492px 439px #FFF , 1731px 1581px #FFF , 1504px 1279px #FFF , 874px 1567px #FFF , 1147px 721px #FFF , 1870px 391px #FFF , 245px 480px #FFF , 356px 1344px #FFF , 545px 1682px #FFF , 260px 941px #FFF , 530px 767px #FFF , 46px 1671px #FFF , 1746px 429px #FFF , 136px 1876px #FFF , 1638px 1670px #FFF , 1176px 1550px #FFF , 1377px 1527px #FFF , 1289px 491px #FFF , 564px 11px #FFF , 1714px 86px #FFF , 335px 83px #FFF , 1949px 940px #FFF , 524px 1016px #FFF , 1358px 1668px #FFF , 1873px 738px #FFF , 1192px 120px #FFF , 808px 1071px #FFF , 336px 1294px #FFF , 1994px 356px #FFF , 1216px 1590px #FFF , 725px 602px #FFF , 1764px 746px #FFF , 911px 94px #FFF , 1754px 1522px #FFF , 1679px 1457px #FFF , 1580px 1613px #FFF , 1195px 579px #FFF , 1576px 341px #FFF , 894px 1819px #FFF , 811px 344px #FFF , 37px 1722px #FFF , 1668px 1830px #FFF , 1821px 867px #FFF , 1642px 630px #FFF , 1000px 1162px #FFF , 1414px 1301px #FFF , 490px 922px #FFF , 286px 1160px #FFF , 108px 1061px #FFF , 1670px 378px #FFF , 407px 1099px #FFF , 1942px 1534px #FFF , 580px 402px #FFF , 265px 1745px #FFF , 585px 687px #FFF , 1968px 108px #FFF , 1890px 1425px #FFF , 666px 919px #FFF , 725px 1155px #FFF , 148px 1645px #FFF , 391px 1299px #FFF , 178px 62px #FFF , 1788px 798px #FFF , 514px 1719px #FFF , 322px 1741px #FFF , 1555px 1146px #FFF , 1506px 1726px #FFF , 43px 1242px #FFF , 1569px 10px #FFF , 6px 95px #FFF;
    animation: animStar 50s linear infinite;
  }
  #stars:after {
    content: " ";
    position: absolute;
    top: 2000px;
    width: 1px;
    height: 1px;
    background: transparent;
    box-shadow: 952px 255px #FFF , 103px 1952px #FFF , 485px 1038px #FFF , 776px 1327px #FFF , 773px 301px #FFF , 1047px 1527px #FFF , 1991px 1969px #FFF , 1654px 1410px #FFF , 1051px 1688px #FFF , 1264px 1151px #FFF , 65px 1263px #FFF , 1391px 1757px #FFF , 1606px 1843px #FFF , 335px 1562px #FFF , 1333px 1942px #FFF , 678px 687px #FFF , 767px 1147px #FFF , 405px 782px #FFF , 986px 1344px #FFF , 951px 988px #FFF , 1428px 1006px #FFF , 1071px 1837px #FFF , 201px 1150px #FFF , 660px 211px #FFF , 808px 1717px #FFF , 1360px 1868px #FFF , 1674px 1250px #FFF , 1257px 945px #FFF , 308px 109px #FFF , 1030px 897px #FFF , 684px 1279px #FFF , 1392px 1890px #FFF , 239px 1198px #FFF , 719px 754px #FFF , 1017px 913px #FFF , 861px 283px #FFF , 1703px 247px #FFF , 1252px 1221px #FFF , 1982px 1952px #FFF , 1772px 1416px #FFF , 770px 1562px #FFF , 978px 1863px #FFF , 364px 995px #FFF , 256px 254px #FFF , 372px 1242px #FFF , 597px 857px #FFF , 799px 1233px #FFF , 1583px 990px #FFF , 57px 1145px #FFF , 284px 1645px #FFF , 1958px 691px #FFF , 686px 1806px #FFF , 739px 988px #FFF , 1776px 1730px #FFF , 1947px 33px #FFF , 1613px 958px #FFF , 1516px 1927px #FFF , 1705px 1152px #FFF , 1138px 1699px #FFF , 260px 972px #FFF , 1709px 225px #FFF , 636px 1520px #FFF , 1866px 1104px #FFF , 151px 1990px #FFF , 1790px 1191px #FFF , 1093px 1977px #FFF , 341px 316px #FFF , 1255px 676px #FFF , 1954px 119px #FFF , 299px 280px #FFF , 287px 68px #FFF , 1300px 360px #FFF , 278px 1083px #FFF , 1124px 913px #FFF , 887px 512px #FFF , 631px 107px #FFF , 1491px 572px #FFF , 1382px 831px #FFF , 1276px 566px #FFF , 1817px 710px #FFF , 1155px 1307px #FFF , 1336px 1298px #FFF , 107px 863px #FFF , 37px 1816px #FFF , 856px 351px #FFF , 1886px 205px #FFF , 1631px 67px #FFF , 689px 787px #FFF , 1959px 1995px #FFF , 1119px 1967px #FFF , 1134px 1535px #FFF , 951px 666px #FFF , 1290px 62px #FFF , 347px 1634px #FFF , 529px 376px #FFF , 1511px 98px #FFF , 1355px 1547px #FFF , 1583px 117px #FFF , 479px 321px #FFF , 1205px 1013px #FFF , 1073px 853px #FFF , 506px 19px #FFF , 80px 1244px #FFF , 353px 345px #FFF , 1785px 87px #FFF , 1825px 724px #FFF , 1563px 8px #FFF , 1007px 1718px #FFF , 1962px 1184px #FFF , 1246px 1365px #FFF , 267px 1086px #FFF , 1222px 475px #FFF , 1154px 723px #FFF , 1733px 728px #FFF , 1132px 54px #FFF , 1685px 1402px #FFF , 929px 1602px #FFF , 166px 1137px #FFF , 1004px 551px #FFF , 1034px 203px #FFF , 1715px 1363px #FFF , 1939px 1807px #FFF , 1370px 1725px #FFF , 357px 1564px #FFF , 860px 1477px #FFF , 1137px 264px #FFF , 983px 1556px #FFF , 1785px 1205px #FFF , 1613px 1788px #FFF , 724px 988px #FFF , 1051px 26px #FFF , 118px 1955px #FFF , 888px 1827px #FFF , 1094px 335px #FFF , 505px 356px #FFF , 1781px 1339px #FFF , 1055px 842px #FFF , 1981px 1509px #FFF , 1786px 1825px #FFF , 719px 576px #FFF , 311px 1260px #FFF , 1270px 1771px #FFF , 213px 1137px #FFF , 168px 1205px #FFF , 1752px 1232px #FFF , 1330px 805px #FFF , 513px 1101px #FFF , 1185px 76px #FFF , 1848px 55px #FFF , 687px 208px #FFF , 193px 640px #FFF , 179px 142px #FFF , 1030px 177px #FFF , 1725px 488px #FFF , 483px 161px #FFF , 1004px 1770px #FFF , 1560px 1469px #FFF , 519px 1520px #FFF , 987px 233px #FFF , 263px 982px #FFF , 528px 1775px #FFF , 220px 538px #FFF , 1395px 1381px #FFF , 1559px 132px #FFF , 94px 1671px #FFF , 1485px 351px #FFF , 1161px 612px #FFF , 1282px 10px #FFF , 446px 432px #FFF , 1072px 1096px #FFF , 1814px 1832px #FFF , 163px 689px #FFF , 802px 351px #FFF , 1279px 1246px #FFF , 477px 143px #FFF , 766px 7px #FFF , 1140px 241px #FFF , 457px 481px #FFF , 299px 1039px #FFF , 380px 913px #FFF , 1456px 760px #FFF , 406px 257px #FFF , 1206px 1448px #FFF , 1321px 106px #FFF , 719px 1354px #FFF , 1609px 526px #FFF , 1316px 1982px #FFF , 1925px 1292px #FFF , 1450px 761px #FFF , 410px 157px #FFF , 1657px 1479px #FFF , 1727px 232px #FFF , 1656px 1697px #FFF , 1087px 324px #FFF , 926px 1081px #FFF , 1114px 1604px #FFF , 1545px 133px #FFF , 886px 59px #FFF , 1993px 1744px #FFF , 1921px 1032px #FFF , 454px 1721px #FFF , 135px 1942px #FFF , 210px 1208px #FFF , 725px 1421px #FFF , 853px 1934px #FFF , 1062px 1933px #FFF , 1220px 167px #FFF , 1280px 1186px #FFF , 210px 617px #FFF , 1216px 882px #FFF , 60px 1180px #FFF , 379px 1074px #FFF , 1943px 1808px #FFF , 532px 314px #FFF , 747px 1092px #FFF , 1972px 598px #FFF , 911px 953px #FFF , 1251px 256px #FFF , 768px 1608px #FFF , 1966px 1136px #FFF , 532px 1032px #FFF , 126px 210px #FFF , 1586px 1202px #FFF , 1576px 392px #FFF , 1133px 141px #FFF , 667px 1625px #FFF , 1193px 1872px #FFF , 1492px 1866px #FFF , 826px 1617px #FFF , 676px 1397px #FFF , 1312px 1338px #FFF , 1044px 714px #FFF , 719px 1655px #FFF , 1459px 1147px #FFF , 1126px 618px #FFF , 1749px 1557px #FFF , 267px 768px #FFF , 1416px 1865px #FFF , 1685px 839px #FFF , 270px 100px #FFF , 276px 1666px #FFF , 60px 1872px #FFF , 1830px 1183px #FFF , 1539px 330px #FFF , 495px 102px #FFF , 1532px 1959px #FFF , 955px 892px #FFF , 727px 1129px #FFF , 1092px 939px #FFF , 505px 1347px #FFF , 139px 89px #FFF , 106px 617px #FFF , 1215px 1217px #FFF , 508px 1828px #FFF , 1968px 43px #FFF , 1584px 663px #FFF , 1101px 1258px #FFF , 1033px 871px #FFF , 997px 799px #FFF , 199px 2px #FFF , 145px 1995px #FFF , 1772px 497px #FFF , 148px 827px #FFF , 723px 1502px #FFF , 1999px 196px #FFF , 1067px 1466px #FFF , 1864px 1533px #FFF , 813px 647px #FFF , 23px 77px #FFF , 842px 1252px #FFF , 1947px 1123px #FFF , 245px 804px #FFF , 1013px 1359px #FFF , 1195px 1535px #FFF , 728px 84px #FFF , 1625px 1316px #FFF , 362px 691px #FFF , 742px 1496px #FFF , 137px 1065px #FFF , 1575px 1143px #FFF , 1579px 1513px #FFF , 218px 1943px #FFF , 763px 1734px #FFF , 710px 621px #FFF , 741px 1260px #FFF , 305px 429px #FFF , 1372px 1079px #FFF , 851px 92px #FFF , 180px 804px #FFF , 1964px 294px #FFF , 891px 1299px #FFF , 1859px 1692px #FFF , 1660px 1945px #FFF , 673px 1193px #FFF , 1133px 211px #FFF , 671px 270px #FFF , 736px 1100px #FFF , 365px 394px #FFF , 402px 827px #FFF , 985px 351px #FFF , 258px 1028px #FFF , 1007px 930px #FFF , 256px 739px #FFF , 590px 1545px #FFF , 606px 1988px #FFF , 552px 159px #FFF , 325px 566px #FFF , 261px 1640px #FFF , 1719px 1781px #FFF , 193px 1952px #FFF , 620px 290px #FFF , 947px 558px #FFF , 339px 109px #FFF , 790px 75px #FFF , 1615px 596px #FFF , 1038px 1041px #FFF , 1612px 774px #FFF , 370px 1126px #FFF , 1091px 1666px #FFF , 129px 1093px #FFF , 141px 475px #FFF , 1085px 1223px #FFF , 1117px 751px #FFF , 1430px 1705px #FFF , 571px 82px #FFF , 1094px 418px #FFF , 319px 1019px #FFF , 570px 774px #FFF , 1318px 751px #FFF , 327px 421px #FFF , 1258px 511px #FFF , 1807px 741px #FFF , 1629px 1005px #FFF , 1100px 1386px #FFF , 1771px 1413px #FFF , 1316px 288px #FFF , 1248px 1331px #FFF , 1524px 221px #FFF , 1576px 1391px #FFF , 1090px 983px #FFF , 1556px 1366px #FFF , 1453px 1604px #FFF , 502px 991px #FFF , 1214px 1479px #FFF , 561px 650px #FFF , 939px 168px #FFF , 188px 1058px #FFF , 1885px 697px #FFF , 1067px 1732px #FFF , 296px 1099px #FFF , 779px 740px #FFF , 37px 1436px #FFF , 355px 878px #FFF , 1063px 107px #FFF , 977px 1762px #FFF , 1052px 744px #FFF , 1501px 235px #FFF , 84px 1006px #FFF , 1082px 1672px #FFF , 1810px 431px #FFF , 984px 1695px #FFF , 393px 991px #FFF , 1911px 1854px #FFF , 1724px 58px #FFF , 1460px 1406px #FFF , 674px 1268px #FFF , 865px 1852px #FFF , 1178px 1223px #FFF , 1805px 119px #FFF , 1321px 183px #FFF , 788px 550px #FFF , 605px 1076px #FFF , 511px 1872px #FFF , 1498px 209px #FFF , 1735px 1682px #FFF , 745px 1780px #FFF , 1955px 790px #FFF , 852px 653px #FFF , 508px 521px #FFF , 407px 197px #FFF , 1688px 597px #FFF , 726px 250px #FFF , 760px 1443px #FFF , 208px 1781px #FFF , 700px 1378px #FFF , 905px 609px #FFF , 854px 1954px #FFF , 1109px 1509px #FFF , 66px 1394px #FFF , 282px 985px #FFF , 323px 1163px #FFF , 1540px 1341px #FFF , 45px 1286px #FFF , 807px 921px #FFF , 790px 1833px #FFF , 1633px 726px #FFF , 1330px 1894px #FFF , 1591px 1802px #FFF , 1350px 230px #FFF , 1320px 1373px #FFF , 1100px 273px #FFF , 1175px 1679px #FFF , 557px 1229px #FFF , 1700px 1691px #FFF , 725px 560px #FFF , 1589px 1593px #FFF , 1459px 1914px #FFF , 175px 2px #FFF , 960px 1110px #FFF , 874px 80px #FFF , 548px 402px #FFF , 958px 1124px #FFF , 1419px 1179px #FFF , 909px 366px #FFF , 291px 21px #FFF , 914px 714px #FFF , 653px 947px #FFF , 1205px 1501px #FFF , 117px 193px #FFF , 140px 1161px #FFF , 99px 259px #FFF , 1499px 211px #FFF , 367px 1439px #FFF , 1146px 35px #FFF , 295px 1104px #FFF , 1338px 606px #FFF , 212px 1605px #FFF , 994px 492px #FFF , 1922px 1798px #FFF , 661px 1118px #FFF , 1271px 1746px #FFF , 560px 1761px #FFF , 684px 1603px #FFF , 1936px 449px #FFF , 1279px 1478px #FFF , 965px 1810px #FFF , 1919px 469px #FFF , 1277px 1438px #FFF , 1916px 907px #FFF , 282px 930px #FFF , 1759px 501px #FFF , 883px 1672px #FFF , 991px 855px #FFF , 1502px 1533px #FFF , 52px 875px #FFF , 1883px 1030px #FFF , 364px 1541px #FFF , 68px 597px #FFF , 1692px 1046px #FFF , 1885px 441px #FFF , 1426px 1929px #FFF , 466px 1591px #FFF , 37px 1770px #FFF , 1377px 209px #FFF , 465px 1490px #FFF , 638px 942px #FFF , 1614px 223px #FFF , 12px 1066px #FFF , 1724px 362px #FFF , 474px 513px #FFF , 999px 863px #FFF , 1292px 1008px #FFF , 993px 48px #FFF , 54px 382px #FFF , 34px 1114px #FFF , 552px 896px #FFF , 868px 441px #FFF , 1600px 1729px #FFF , 1577px 55px #FFF , 1989px 606px #FFF , 645px 656px #FFF , 1766px 352px #FFF , 302px 550px #FFF , 144px 1091px #FFF , 400px 1163px #FFF , 1178px 1283px #FFF , 1638px 105px #FFF , 1595px 1551px #FFF , 369px 1857px #FFF , 1516px 411px #FFF , 663px 297px #FFF , 701px 141px #FFF , 496px 1854px #FFF , 1154px 1300px #FFF , 1579px 102px #FFF , 1071px 1958px #FFF , 916px 1268px #FFF , 1130px 1648px #FFF , 1352px 1342px #FFF , 1478px 1603px #FFF , 46px 1999px #FFF , 1062px 1038px #FFF , 1766px 877px #FFF , 770px 712px #FFF , 317px 1402px #FFF , 1699px 188px #FFF , 227px 318px #FFF , 1976px 142px #FFF , 1486px 502px #FFF , 104px 1010px #FFF , 1052px 1505px #FFF , 1045px 795px #FFF , 217px 650px #FFF , 361px 828px #FFF , 615px 1133px #FFF , 1277px 619px #FFF , 1958px 635px #FFF , 1194px 1345px #FFF , 863px 1878px #FFF , 1722px 381px #FFF , 657px 223px #FFF , 585px 95px #FFF , 1904px 1278px #FFF , 850px 829px #FFF , 73px 1113px #FFF , 411px 1198px #FFF , 1941px 752px #FFF , 1748px 761px #FFF , 1022px 1321px #FFF , 1818px 107px #FFF , 1273px 819px #FFF , 1497px 1321px #FFF , 1472px 1372px #FFF , 290px 1292px #FFF , 337px 309px #FFF , 1250px 684px #FFF , 1788px 1520px #FFF , 1433px 1960px #FFF , 1179px 707px #FFF , 107px 958px #FFF , 886px 497px #FFF , 864px 173px #FFF , 174px 909px #FFF , 1851px 310px #FFF , 675px 144px #FFF , 143px 1028px #FFF , 36px 1960px #FFF , 322px 1664px #FFF , 749px 170px #FFF , 1183px 1661px #FFF , 229px 471px #FFF , 1714px 1866px #FFF , 1882px 1524px #FFF , 1475px 1399px #FFF , 906px 1991px #FFF , 485px 226px #FFF , 75px 1842px #FFF , 866px 560px #FFF , 235px 807px #FFF , 1707px 996px #FFF , 744px 208px #FFF , 1857px 1325px #FFF , 1279px 1027px #FFF , 1174px 1416px #FFF , 1684px 950px #FFF , 270px 122px #FFF , 63px 1090px #FFF , 771px 723px #FFF , 1146px 1486px #FFF , 1243px 502px #FFF , 1578px 942px #FFF , 113px 1809px #FFF , 380px 678px #FFF , 1531px 325px #FFF , 366px 1099px #FFF , 826px 445px #FFF , 431px 269px #FFF , 454px 1861px #FFF , 1907px 151px #FFF , 208px 1185px #FFF , 1409px 752px #FFF , 687px 1787px #FFF , 333px 1198px #FFF , 1545px 870px #FFF , 1225px 1225px #FFF , 575px 1673px #FFF , 236px 168px #FFF , 1030px 749px #FFF , 1419px 640px #FFF , 250px 1214px #FFF , 1322px 792px #FFF , 39px 565px #FFF , 1366px 799px #FFF , 873px 1920px #FFF , 1255px 430px #FFF , 1644px 1109px #FFF , 1534px 608px #FFF , 1111px 1120px #FFF , 737px 1591px #FFF , 1661px 1852px #FFF , 539px 1858px #FFF , 550px 1906px #FFF , 979px 513px #FFF , 289px 558px #FFF , 220px 157px #FFF , 172px 744px #FFF , 1807px 1832px #FFF , 708px 10px #FFF , 1273px 1231px #FFF , 1956px 1590px #FFF , 250px 1134px #FFF , 1658px 1662px #FFF , 1282px 1683px #FFF , 271px 894px #FFF , 1221px 1283px #FFF , 1928px 891px #FFF , 955px 924px #FFF , 1051px 197px #FFF , 863px 26px #FFF , 306px 365px #FFF , 1028px 621px #FFF , 1737px 877px #FFF , 91px 247px #FFF , 918px 20px #FFF , 1944px 1264px #FFF , 566px 415px #FFF , 599px 1178px #FFF , 1961px 891px #FFF , 643px 1584px #FFF , 913px 1835px #FFF , 945px 1658px #FFF , 1167px 666px #FFF , 515px 299px #FFF , 557px 246px #FFF , 74px 874px #FFF , 833px 101px #FFF , 671px 435px #FFF , 124px 430px #FFF , 740px 992px #FFF , 323px 1552px #FFF , 492px 439px #FFF , 1731px 1581px #FFF , 1504px 1279px #FFF , 874px 1567px #FFF , 1147px 721px #FFF , 1870px 391px #FFF , 245px 480px #FFF , 356px 1344px #FFF , 545px 1682px #FFF , 260px 941px #FFF , 530px 767px #FFF , 46px 1671px #FFF , 1746px 429px #FFF , 136px 1876px #FFF , 1638px 1670px #FFF , 1176px 1550px #FFF , 1377px 1527px #FFF , 1289px 491px #FFF , 564px 11px #FFF , 1714px 86px #FFF , 335px 83px #FFF , 1949px 940px #FFF , 524px 1016px #FFF , 1358px 1668px #FFF , 1873px 738px #FFF , 1192px 120px #FFF , 808px 1071px #FFF , 336px 1294px #FFF , 1994px 356px #FFF , 1216px 1590px #FFF , 725px 602px #FFF , 1764px 746px #FFF , 911px 94px #FFF , 1754px 1522px #FFF , 1679px 1457px #FFF , 1580px 1613px #FFF , 1195px 579px #FFF , 1576px 341px #FFF , 894px 1819px #FFF , 811px 344px #FFF , 37px 1722px #FFF , 1668px 1830px #FFF , 1821px 867px #FFF , 1642px 630px #FFF , 1000px 1162px #FFF , 1414px 1301px #FFF , 490px 922px #FFF , 286px 1160px #FFF , 108px 1061px #FFF , 1670px 378px #FFF , 407px 1099px #FFF , 1942px 1534px #FFF , 580px 402px #FFF , 265px 1745px #FFF , 585px 687px #FFF , 1968px 108px #FFF , 1890px 1425px #FFF , 666px 919px #FFF , 725px 1155px #FFF , 148px 1645px #FFF , 391px 1299px #FFF , 178px 62px #FFF , 1788px 798px #FFF , 514px 1719px #FFF , 322px 1741px #FFF , 1555px 1146px #FFF , 1506px 1726px #FFF , 43px 1242px #FFF , 1569px 10px #FFF , 6px 95px #FFF;
  }
  
  #stars2 {
    width: 2px;
    height: 2px;
    background: transparent;
    box-shadow: 668px 1055px #FFF , 1279px 1497px #FFF , 1270px 847px #FFF , 1481px 296px #FFF , 716px 1569px #FFF , 1349px 1291px #FFF , 1728px 631px #FFF , 39px 322px #FFF , 975px 421px #FFF , 967px 1695px #FFF , 605px 1100px #FFF , 1445px 1781px #FFF , 1853px 1074px #FFF , 1156px 345px #FFF , 98px 1904px #FFF , 1374px 1994px #FFF , 82px 866px #FFF , 728px 1376px #FFF , 665px 1062px #FFF , 1597px 1326px #FFF , 957px 1694px #FFF , 1418px 1266px #FFF , 1214px 100px #FFF , 552px 393px #FFF , 83px 717px #FFF , 894px 1437px #FFF , 347px 784px #FFF , 1477px 922px #FFF , 210px 760px #FFF , 907px 1939px #FFF , 1834px 1419px #FFF , 225px 1465px #FFF , 1190px 1076px #FFF , 572px 1295px #FFF , 61px 81px #FFF , 792px 242px #FFF , 290px 908px #FFF , 1421px 1677px #FFF , 1433px 483px #FFF , 565px 599px #FFF , 188px 1328px #FFF , 1303px 596px #FFF , 1934px 1854px #FFF , 1970px 174px #FFF , 1326px 1321px #FFF , 1486px 1185px #FFF , 1235px 1265px #FFF , 99px 299px #FFF , 861px 271px #FFF , 477px 792px #FFF , 988px 136px #FFF , 270px 1696px #FFF , 157px 902px #FFF , 606px 365px #FFF , 1794px 523px #FFF , 1524px 1039px #FFF , 1092px 1701px #FFF , 1258px 434px #FFF , 258px 1770px #FFF , 1633px 449px #FFF , 17px 624px #FFF , 914px 667px #FFF , 1222px 1134px #FFF , 1832px 214px #FFF , 183px 1996px #FFF , 1209px 548px #FFF , 923px 1830px #FFF , 1213px 850px #FFF , 798px 1212px #FFF , 1773px 607px #FFF , 1821px 1139px #FFF , 322px 273px #FFF , 1367px 1715px #FFF , 489px 1565px #FFF , 520px 229px #FFF , 1456px 59px #FFF , 305px 908px #FFF , 982px 145px #FFF , 325px 302px #FFF , 1746px 304px #FFF , 1240px 653px #FFF , 1279px 882px #FFF , 1283px 1550px #FFF , 1452px 915px #FFF , 311px 1913px #FFF , 1453px 1545px #FFF , 754px 792px #FFF , 1422px 1025px #FFF , 768px 1068px #FFF , 233px 540px #FFF , 1832px 529px #FFF , 669px 644px #FFF , 1493px 1981px #FFF , 1883px 382px #FFF , 1771px 1533px #FFF , 439px 511px #FFF , 244px 1587px #FFF , 1382px 199px #FFF , 1680px 1419px #FFF , 730px 1694px #FFF , 300px 1803px #FFF , 1812px 1605px #FFF , 1217px 164px #FFF , 1488px 1015px #FFF , 45px 453px #FFF , 859px 1948px #FFF , 1013px 576px #FFF , 1238px 1364px #FFF , 1107px 730px #FFF , 1053px 262px #FFF , 1813px 863px #FFF , 1936px 1714px #FFF , 1536px 1282px #FFF , 1533px 554px #FFF , 688px 92px #FFF , 166px 1738px #FFF , 1634px 1313px #FFF , 687px 1544px #FFF , 794px 1460px #FFF , 1042px 1138px #FFF , 383px 1532px #FFF , 968px 483px #FFF , 1654px 1877px #FFF , 926px 1146px #FFF , 1327px 1390px #FFF , 473px 361px #FFF , 449px 893px #FFF , 815px 411px #FFF , 420px 1757px #FFF , 171px 64px #FFF , 220px 1746px #FFF , 1081px 1917px #FFF , 1152px 793px #FFF , 1439px 688px #FFF , 1044px 169px #FFF , 710px 1197px #FFF , 61px 761px #FFF , 913px 50px #FFF , 1195px 907px #FFF , 1875px 1931px #FFF , 1645px 1921px #FFF , 1098px 105px #FFF , 1425px 44px #FFF , 1011px 696px #FFF , 1849px 1028px #FFF , 172px 1609px #FFF , 981px 591px #FFF , 702px 501px #FFF , 1343px 1074px #FFF , 1724px 1083px #FFF , 65px 551px #FFF , 291px 1312px #FFF , 1429px 1829px #FFF , 192px 1360px #FFF , 1705px 1131px #FFF , 1923px 1219px #FFF , 1415px 434px #FFF , 1961px 188px #FFF , 1055px 1151px #FFF , 1246px 230px #FFF , 341px 1283px #FFF , 521px 590px #FFF , 429px 1664px #FFF , 1323px 1004px #FFF , 1931px 1531px #FFF , 1205px 1738px #FFF , 639px 1200px #FFF , 162px 934px #FFF , 1802px 1413px #FFF , 1678px 1892px #FFF , 1444px 1290px #FFF , 582px 558px #FFF , 1462px 761px #FFF , 1780px 847px #FFF , 1627px 1364px #FFF , 930px 1276px #FFF , 694px 821px #FFF , 256px 1184px #FFF , 1568px 124px #FFF , 1867px 504px #FFF , 251px 959px #FFF , 778px 1651px #FFF , 1995px 1544px #FFF , 1548px 321px #FFF , 1907px 1591px #FFF , 669px 1965px #FFF , 1069px 943px #FFF , 595px 1839px #FFF , 1780px 1659px #FFF , 1930px 878px #FFF , 1120px 616px #FFF , 38px 860px #FFF , 278px 1008px #FFF , 1707px 241px #FFF , 226px 149px #FFF , 974px 1929px #FFF , 785px 1176px #FFF , 976px 1546px #FFF , 661px 1376px #FFF , 693px 866px #FFF;
    animation: animStar 100s linear infinite;
  }
  #stars2:after {
    content: " ";
    position: absolute;
    top: 2000px;
    width: 2px;
    height: 2px;
    background: transparent;
    box-shadow: 668px 1055px #FFF , 1279px 1497px #FFF , 1270px 847px #FFF , 1481px 296px #FFF , 716px 1569px #FFF , 1349px 1291px #FFF , 1728px 631px #FFF , 39px 322px #FFF , 975px 421px #FFF , 967px 1695px #FFF , 605px 1100px #FFF , 1445px 1781px #FFF , 1853px 1074px #FFF , 1156px 345px #FFF , 98px 1904px #FFF , 1374px 1994px #FFF , 82px 866px #FFF , 728px 1376px #FFF , 665px 1062px #FFF , 1597px 1326px #FFF , 957px 1694px #FFF , 1418px 1266px #FFF , 1214px 100px #FFF , 552px 393px #FFF , 83px 717px #FFF , 894px 1437px #FFF , 347px 784px #FFF , 1477px 922px #FFF , 210px 760px #FFF , 907px 1939px #FFF , 1834px 1419px #FFF , 225px 1465px #FFF , 1190px 1076px #FFF , 572px 1295px #FFF , 61px 81px #FFF , 792px 242px #FFF , 290px 908px #FFF , 1421px 1677px #FFF , 1433px 483px #FFF , 565px 599px #FFF , 188px 1328px #FFF , 1303px 596px #FFF , 1934px 1854px #FFF , 1970px 174px #FFF , 1326px 1321px #FFF , 1486px 1185px #FFF , 1235px 1265px #FFF , 99px 299px #FFF , 861px 271px #FFF , 477px 792px #FFF , 988px 136px #FFF , 270px 1696px #FFF , 157px 902px #FFF , 606px 365px #FFF , 1794px 523px #FFF , 1524px 1039px #FFF , 1092px 1701px #FFF , 1258px 434px #FFF , 258px 1770px #FFF , 1633px 449px #FFF , 17px 624px #FFF , 914px 667px #FFF , 1222px 1134px #FFF , 1832px 214px #FFF , 183px 1996px #FFF , 1209px 548px #FFF , 923px 1830px #FFF , 1213px 850px #FFF , 798px 1212px #FFF , 1773px 607px #FFF , 1821px 1139px #FFF , 322px 273px #FFF , 1367px 1715px #FFF , 489px 1565px #FFF , 520px 229px #FFF , 1456px 59px #FFF , 305px 908px #FFF , 982px 145px #FFF , 325px 302px #FFF , 1746px 304px #FFF , 1240px 653px #FFF , 1279px 882px #FFF , 1283px 1550px #FFF , 1452px 915px #FFF , 311px 1913px #FFF , 1453px 1545px #FFF , 754px 792px #FFF , 1422px 1025px #FFF , 768px 1068px #FFF , 233px 540px #FFF , 1832px 529px #FFF , 669px 644px #FFF , 1493px 1981px #FFF , 1883px 382px #FFF , 1771px 1533px #FFF , 439px 511px #FFF , 244px 1587px #FFF , 1382px 199px #FFF , 1680px 1419px #FFF , 730px 1694px #FFF , 300px 1803px #FFF , 1812px 1605px #FFF , 1217px 164px #FFF , 1488px 1015px #FFF , 45px 453px #FFF , 859px 1948px #FFF , 1013px 576px #FFF , 1238px 1364px #FFF , 1107px 730px #FFF , 1053px 262px #FFF , 1813px 863px #FFF , 1936px 1714px #FFF , 1536px 1282px #FFF , 1533px 554px #FFF , 688px 92px #FFF , 166px 1738px #FFF , 1634px 1313px #FFF , 687px 1544px #FFF , 794px 1460px #FFF , 1042px 1138px #FFF , 383px 1532px #FFF , 968px 483px #FFF , 1654px 1877px #FFF , 926px 1146px #FFF , 1327px 1390px #FFF , 473px 361px #FFF , 449px 893px #FFF , 815px 411px #FFF , 420px 1757px #FFF , 171px 64px #FFF , 220px 1746px #FFF , 1081px 1917px #FFF , 1152px 793px #FFF , 1439px 688px #FFF , 1044px 169px #FFF , 710px 1197px #FFF , 61px 761px #FFF , 913px 50px #FFF , 1195px 907px #FFF , 1875px 1931px #FFF , 1645px 1921px #FFF , 1098px 105px #FFF , 1425px 44px #FFF , 1011px 696px #FFF , 1849px 1028px #FFF , 172px 1609px #FFF , 981px 591px #FFF , 702px 501px #FFF , 1343px 1074px #FFF , 1724px 1083px #FFF , 65px 551px #FFF , 291px 1312px #FFF , 1429px 1829px #FFF , 192px 1360px #FFF , 1705px 1131px #FFF , 1923px 1219px #FFF , 1415px 434px #FFF , 1961px 188px #FFF , 1055px 1151px #FFF , 1246px 230px #FFF , 341px 1283px #FFF , 521px 590px #FFF , 429px 1664px #FFF , 1323px 1004px #FFF , 1931px 1531px #FFF , 1205px 1738px #FFF , 639px 1200px #FFF , 162px 934px #FFF , 1802px 1413px #FFF , 1678px 1892px #FFF , 1444px 1290px #FFF , 582px 558px #FFF , 1462px 761px #FFF , 1780px 847px #FFF , 1627px 1364px #FFF , 930px 1276px #FFF , 694px 821px #FFF , 256px 1184px #FFF , 1568px 124px #FFF , 1867px 504px #FFF , 251px 959px #FFF , 778px 1651px #FFF , 1995px 1544px #FFF , 1548px 321px #FFF , 1907px 1591px #FFF , 669px 1965px #FFF , 1069px 943px #FFF , 595px 1839px #FFF , 1780px 1659px #FFF , 1930px 878px #FFF , 1120px 616px #FFF , 38px 860px #FFF , 278px 1008px #FFF , 1707px 241px #FFF , 226px 149px #FFF , 974px 1929px #FFF , 785px 1176px #FFF , 976px 1546px #FFF , 661px 1376px #FFF , 693px 866px #FFF;
  }
  
  #stars3 {
    width: 3px;
    height: 3px;
    background: transparent;
    box-shadow: 824px 1147px #FFF , 805px 1839px #FFF , 1278px 121px #FFF , 1492px 1839px #FFF , 1540px 443px #FFF , 2000px 300px #FFF , 807px 1252px #FFF , 1268px 578px #FFF , 1450px 1718px #FFF , 117px 75px #FFF , 483px 1591px #FFF , 1046px 1010px #FFF , 1699px 1311px #FFF , 351px 440px #FFF , 670px 1394px #FFF , 1231px 432px #FFF , 1030px 139px #FFF , 123px 688px #FFF , 723px 14px #FFF , 58px 1944px #FFF , 1104px 911px #FFF , 36px 1481px #FFF , 1466px 1056px #FFF , 678px 141px #FFF , 1414px 598px #FFF , 158px 1322px #FFF , 398px 1132px #FFF , 563px 1621px #FFF , 1470px 1460px #FFF , 786px 1025px #FFF , 1364px 1603px #FFF , 574px 640px #FFF , 1562px 316px #FFF , 2px 528px #FFF , 1259px 322px #FFF , 556px 1439px #FFF , 1658px 402px #FFF , 567px 1276px #FFF , 663px 1119px #FFF , 892px 4px #FFF , 1491px 1232px #FFF , 826px 1159px #FFF , 858px 1866px #FFF , 1821px 6px #FFF , 1723px 1619px #FFF , 394px 935px #FFF , 263px 100px #FFF , 1239px 373px #FFF , 1353px 1506px #FFF , 743px 568px #FFF , 1864px 1860px #FFF , 263px 1064px #FFF , 1338px 1157px #FFF , 1120px 1628px #FFF , 1840px 855px #FFF , 62px 274px #FFF , 1173px 340px #FFF , 1615px 1536px #FFF , 731px 999px #FFF , 370px 361px #FFF , 149px 493px #FFF , 1959px 1084px #FFF , 322px 818px #FFF , 1310px 209px #FFF , 1692px 1753px #FFF , 265px 1494px #FFF , 609px 1504px #FFF , 1323px 1648px #FFF , 907px 453px #FFF , 568px 486px #FFF , 1971px 359px #FFF , 281px 1077px #FFF , 1446px 1952px #FFF , 1978px 1142px #FFF , 379px 43px #FFF , 1365px 105px #FFF , 629px 603px #FFF , 1332px 29px #FFF , 6px 1537px #FFF , 1466px 842px #FFF , 1459px 134px #FFF , 513px 926px #FFF , 836px 611px #FFF , 666px 1844px #FFF , 1965px 1171px #FFF , 638px 1941px #FFF , 1041px 1660px #FFF , 680px 685px #FFF , 61px 346px #FFF , 1247px 1348px #FFF , 1981px 207px #FFF , 536px 1753px #FFF , 1907px 226px #FFF , 1749px 138px #FFF , 1177px 1486px #FFF , 174px 1587px #FFF , 976px 119px #FFF , 1590px 1209px #FFF , 164px 637px #FFF , 1263px 616px #FFF;
    animation: animStar 150s linear infinite;
  }
  #stars3:after {
    content: " ";
    position: absolute;
    top: 2000px;
    width: 3px;
    height: 3px;
    background: transparent;
    box-shadow: 824px 1147px #FFF , 805px 1839px #FFF , 1278px 121px #FFF , 1492px 1839px #FFF , 1540px 443px #FFF , 2000px 300px #FFF , 807px 1252px #FFF , 1268px 578px #FFF , 1450px 1718px #FFF , 117px 75px #FFF , 483px 1591px #FFF , 1046px 1010px #FFF , 1699px 1311px #FFF , 351px 440px #FFF , 670px 1394px #FFF , 1231px 432px #FFF , 1030px 139px #FFF , 123px 688px #FFF , 723px 14px #FFF , 58px 1944px #FFF , 1104px 911px #FFF , 36px 1481px #FFF , 1466px 1056px #FFF , 678px 141px #FFF , 1414px 598px #FFF , 158px 1322px #FFF , 398px 1132px #FFF , 563px 1621px #FFF , 1470px 1460px #FFF , 786px 1025px #FFF , 1364px 1603px #FFF , 574px 640px #FFF , 1562px 316px #FFF , 2px 528px #FFF , 1259px 322px #FFF , 556px 1439px #FFF , 1658px 402px #FFF , 567px 1276px #FFF , 663px 1119px #FFF , 892px 4px #FFF , 1491px 1232px #FFF , 826px 1159px #FFF , 858px 1866px #FFF , 1821px 6px #FFF , 1723px 1619px #FFF , 394px 935px #FFF , 263px 100px #FFF , 1239px 373px #FFF , 1353px 1506px #FFF , 743px 568px #FFF , 1864px 1860px #FFF , 263px 1064px #FFF , 1338px 1157px #FFF , 1120px 1628px #FFF , 1840px 855px #FFF , 62px 274px #FFF , 1173px 340px #FFF , 1615px 1536px #FFF , 731px 999px #FFF , 370px 361px #FFF , 149px 493px #FFF , 1959px 1084px #FFF , 322px 818px #FFF , 1310px 209px #FFF , 1692px 1753px #FFF , 265px 1494px #FFF , 609px 1504px #FFF , 1323px 1648px #FFF , 907px 453px #FFF , 568px 486px #FFF , 1971px 359px #FFF , 281px 1077px #FFF , 1446px 1952px #FFF , 1978px 1142px #FFF , 379px 43px #FFF , 1365px 105px #FFF , 629px 603px #FFF , 1332px 29px #FFF , 6px 1537px #FFF , 1466px 842px #FFF , 1459px 134px #FFF , 513px 926px #FFF , 836px 611px #FFF , 666px 1844px #FFF , 1965px 1171px #FFF , 638px 1941px #FFF , 1041px 1660px #FFF , 680px 685px #FFF , 61px 346px #FFF , 1247px 1348px #FFF , 1981px 207px #FFF , 536px 1753px #FFF , 1907px 226px #FFF , 1749px 138px #FFF , 1177px 1486px #FFF , 174px 1587px #FFF , 976px 119px #FFF , 1590px 1209px #FFF , 164px 637px #FFF , 1263px 616px #FFF;
  }
  
  #title {
    position: absolute;
    top: 50%;
    left: 0;
    right: 0;
    color: #FFF;
    text-align: center;
    font-family: "lato", sans-serif;
    font-weight: 300;
    font-size: 50px;
    letter-spacing: 10px;
    margin-top: -60px;
    padding-left: 10px;
  }
  #title span {
    background: -webkit-linear-gradient(white, #38495a);
    background-clip: unset;
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
  }
  
  @keyframes animStar {
    from {
      transform: translateY(0px);
    }
    to {
      transform: translateY(-2000px);
    }
  }
  .links:hover
  {
       background-color: #818181;
       color: white !important;
  }
      
  .olinks:hover
  {
       background-color: #818181;
       color: white !important;
  }
  .links
{
     z-index:9999999;
}
.olinks
{
     z-index:9999999;
}
   
  
               
          </style>


</head>

<body>

<div id="myNav" class="overlay">
                <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
                <div class="overlay-content">
                <a href="https://www.ktj.in/main.html" class="olinks">Home</a>
                        <a href="<?= base_url() ?>index.php/register" class="olinks">Registration</a>
                        <a href="<?= base_url() ?>index.php/events" class="olinks">Event</a>
                        <a href="<?= base_url() ?>index.php/soon" class="olinks">Workshops</a>
                        <a href="<?= base_url() ?>index.php/soon" class="olinks">Exhibition</a>
                        <a href="<?= base_url() ?>index.php/soon" class="olinks">Guest Lecture</a>
                        <a href="<?= base_url() ?>index.php/soon" class="olinks">Accomodation</a>
                        <a href="<?= base_url() ?>index.php/soon" class="olinks">Notices</a>
                        <a href="<?= base_url() ?>index.php/sponsors/2019" class="olinks">Sponsors</a>
                        <a href="#" class="olinks">Contact us</a>
                        <a href="<?= base_url() ?>index.php/login" class="olinks">Login</a>
                </div>
        </div>

        <img src="<?= base_url() ?>assets/img/iit.png" class="left other" alt="Snow"></img>
        <div class="tnavig">
        <a class="links" href="https://www.ktj.in/main.html">Home</a>
                <a class="links" href="<?= base_url() ?>index.php/register">Registration</a>
                <a class="links" href="<?= base_url() ?>index.php/events">Event</a>
                <a class="links" href="<?= base_url() ?>index.php/soon">Workshops</a>
                <a class="links" href="<?= base_url() ?>index.php/soon">Exhibition</a>
                <a class="links" href="<?= base_url() ?>index.php/soon">Guest Lecture</a>
                <a class="links" href="<?= base_url() ?>index.php/login">Login</a>
                <a href="<?= base_url() ?>index.php/soon" class="links">Accomodation</a>
                <a href="<?= base_url() ?>index.php/sponsors/2019" class="links">Sponsors</a>
                <a href="<?= base_url() ?>index.php/soon" class="links">Notices</a>
                <a href="#" class="links">Contact us</a>
        </div>
        <span class="navig olink" style="font-size:30px;cursor:pointer" onClick="openNav()">&#9776;</span>
        <img src="<?= base_url() ?>assets/img/topright.png" class="right other" alt="Snow"></img>

        <div class='wrap'>
                <div id='stars'></div>
                <div id='stars2'></div>
                <div id='stars3'></div>
        </div>

<script>
        function openNav() {
                document.getElementById("myNav").style.height = "100%";
        }

        function closeNav() {
                document.getElementById("myNav").style.height = "0%";
        }
        var countDownDate = new Date("Jan 17, 2020 00:00:00").getTime();


        var x = setInterval(function () {
                var now = new Date().getTime();
                var distance = countDownDate - now;
                var days = Math.floor(distance / (1000 * 60 * 60 * 24));
                var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
                var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
                var seconds = Math.floor((distance % (1000 * 60)) / 1000);

                document.getElementById("demo").innerHTML = days + "d " + hours + "h "
                        + minutes + "m " + seconds + "s ";
                if (distance < 0) {
                        clearInterval(x);
                        document.getElementById("demo").innerHTML = "EXPIRED";
                }
        }, 1000);
</script>
