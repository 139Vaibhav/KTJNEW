# Kshitij Website
The basic registration and login system is complete.
Next - I Will be working on events and its relation to user

## I have used Bulma css framework as it is small. Of course it will be replaced later.

## database name - kshitij, sql file is assets directory.
,
## For using the Password reset system, mailing is required. 
 - For mailing: go to application/config/email.php and put in your email and password
 - Next go to: https://myaccount.google.com/lesssecureapps and allow gmail to send mail.

### See the config and routes file. If there are any problem tell me.

-- Register
-- Login
-- Events
    -- name
    -- photo
    -- genre
    -- Description
    -- Rules
-- Workshop
    -- name
    -- description
    -- picture
    -- topic
    -- logo
-- Guest Lectures
    -- Name
    -- Designation
    -- Photo
    -- Topic
-- Informals
    -- Name
    -- Photo
-- Exhibitions
    -- Name
    -- Photo
