<canvas id="demo-canvas"></canvas>
    <div class="contact" style="display: flex;width: 80%;">
        <div class="name">
            <h1>Gurdeep Prajapati</h1>
            <h3>Events Head</h3>
            <h3>7431055666</h3>
        </div>
        <div class="name">
            <h1>Yashwant Kolliboyana</h1>
            <h3>Events Head</h3>
            <h3>8309583822</h3>
        </div>
        <div class="name">
            <h1>Balaji Alluru</h1>
            <h3>Events Head</h3>
            <h3>7363048999</h3>
        </div>
        <div class="name">
            <h1>Aman Kumar</h1>
            <h3>Events Head</h3>
            <h3>7478011333</h3>
        </div>
    </div>
    <div class="contact" style="top:60%; display:flex">
        <div class="name">
            <h1>Shubham Garg</h1>
            <h3>Web Co-ordinator</h3>
            <h3>7430088777</h3>
        </div>
        <div class="name">
            <h1>Sudhansu Parashar</h1>
            <h3>Web Co-ordinator</h3>
            <h3>7427922255</h3>
        </div>
    </div>
</div>
<style>
.contact{
    position: absolute;
    top: 20%;
    left: 50%;
    transform: translate(-50%,0);
    padding: 20px;
    text-align: center;
    color: white;
    border: 1px solid white;
}
.name {
    margin: 20px;
}
</style>