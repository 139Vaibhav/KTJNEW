<canvas id="demo-canvas"></canvas>
     <iframe src="<?= base_url() ?>assets/privacypolicy.pdf"></iframe> 
</div>