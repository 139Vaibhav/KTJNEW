<section class="hero is-primary">
    <div class="hero-body">
        <div class="container">
            <h1 class="title">
            Events
            </h1>
            <h2 class="subtitle">
            </h2>
        </div>
    </div>
</section>

<!-- <section class="section">
    <div class="card">
        <div class="card-content">
            <div class="content">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Desc</th>
                            <th>Rules</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($events as $event) : ?>
                        <tr>
                            <td><?= $event->name ?></td>
                            <td><?= $event->description ?></td>
                            <td><?= $event->rules ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</section> -->

