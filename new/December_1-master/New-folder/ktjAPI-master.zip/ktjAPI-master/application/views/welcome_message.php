<div id="form">
	<form>
		<h1>You have been registered for Kshitij 2019.</h1>
		<h2> Your KTJ-ID is <?= $member_id ?></h2>
		<h3 style="color:red">Please note it for future reference.</h3>
		<div><a href="https://ktj.in">Explore KTJ.</a></div>
	</form>
</div> 