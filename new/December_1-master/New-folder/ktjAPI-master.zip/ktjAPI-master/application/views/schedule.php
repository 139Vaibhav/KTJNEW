<canvas id="demo-canvas"></canvas>
     <iframe src="<?= base_url() ?>assets/schedule.pdf"></iframe> 
</div>
