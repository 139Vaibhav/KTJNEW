<!DOCTYPE html>
<html lang="en" >

<head>
  <meta charset="UTF-8">
  <title>Kshitij: Kolkata Workshop</title>
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="viewport" content="width=1366">
  <link rel="icon" href="<?= base_url() ?>assets/Kshitij_Log.png">
  <link rel="stylesheet" href="<?= base_url() ?>assets/css/style.css">
</head>

<body>

  <header>
	<center><h1>Register for <img src="<?= base_url() ?>assets/Kshitij_Logo.png" style="width:85px"> IQ quiz</h1></center>
</header>

<div id="form" class="successf">

<div id="success">

    You have been registered.<br>
    Your registration-id is : <?= $member_id ?> <br>
    Please note it for later use.

</div>

</div>
  <script src='https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js'></script>

</body>

</html>
